const express = require('express');
const router = express.Router();
const db = require('../database');
const { authenticateToken, requireRole } = require('../middleware/auth');

// Obtener reportes personalizados guardados
router.get('/', authenticateToken, (req, res) => {
  const database = db.getDb();
  database.all(`
    SELECT * FROM custom_reports 
    WHERE user_id = ? OR is_public = 1
    ORDER BY created_at DESC
  `, [req.user.id], (err, rows) => {
    if (err) {
      console.error('Error al obtener reportes:', err);
      return res.status(500).json({ error: 'Error al obtener reportes' });
    }
    
    const parsedRows = (rows || []).map(row => ({
      ...row,
      fields: row.fields ? JSON.parse(row.fields) : [],
      filters: row.filters ? JSON.parse(row.filters) : {}
    }));

    res.json(parsedRows);
  });
});

// Crear reporte personalizado
router.post('/', authenticateToken, requireRole(['admin', 'editor']), (req, res) => {
  const { name, description, entity_type, fields, filters, is_public } = req.body;

  if (!name || !entity_type || !fields) {
    return res.status(400).json({ error: 'Faltan campos requeridos' });
  }

  database.run(`
    INSERT INTO custom_reports (user_id, name, description, entity_type, fields, filters, is_public)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `, [
    req.user.id,
    name,
    description || null,
    entity_type,
    JSON.stringify(fields),
    JSON.stringify(filters || {}),
    is_public ? 1 : 0
  ], function(err) {
    if (err) {
      console.error('Error al crear reporte:', err);
      return res.status(500).json({ error: 'Error al crear reporte' });
    }
    res.json({ id: this.lastID, message: 'Reporte creado exitosamente' });
  });
});

// Ejecutar reporte personalizado
router.post('/:id/execute', authenticateToken, (req, res) => {
  const { id } = req.params;
  const { start_date, end_date } = req.body;

  database.get('SELECT * FROM custom_reports WHERE id = ?', [id], (err, report) => {
    if (err) {
      console.error('Error al obtener reporte:', err);
      return res.status(500).json({ error: 'Error al obtener reporte' });
    }
    if (!report) {
      return res.status(404).json({ error: 'Reporte no encontrado' });
    }

    // Verificar permisos
    if (!report.is_public && report.user_id !== req.user.id) {
      return res.status(403).json({ error: 'No tienes permiso para ejecutar este reporte' });
    }

    const fields = JSON.parse(report.fields);
    const filters = JSON.parse(report.filters || '{}');
    const entityType = report.entity_type;

    // Construir query dinámico
    let query = `SELECT ${fields.join(', ')} FROM ${entityType} WHERE 1=1`;
    const params = [];

    if (start_date) {
      query += ` AND DATE(created_at) >= ?`;
      params.push(start_date);
    }
    if (end_date) {
      query += ` AND DATE(created_at) <= ?`;
      params.push(end_date);
    }

    // Aplicar filtros adicionales
    Object.keys(filters).forEach(key => {
      if (filters[key]) {
        query += ` AND ${key} = ?`;
        params.push(filters[key]);
      }
    });

    database.all(query, params, (err, rows) => {
      if (err) {
        console.error('Error al ejecutar reporte:', err);
        return res.status(500).json({ error: 'Error al ejecutar reporte' });
      }
      res.json({ data: rows || [], report_name: report.name });
    });
  });
});

// Eliminar reporte
router.delete('/:id', authenticateToken, requireRole(['admin', 'editor']), (req, res) => {
  const database = db.getDb();
  const { id } = req.params;

  database.run('DELETE FROM custom_reports WHERE id = ? AND (user_id = ? OR ? = "admin")', 
    [id, req.user.id, req.user.role], function(err) {
    if (err) {
      console.error('Error al eliminar reporte:', err);
      return res.status(500).json({ error: 'Error al eliminar reporte' });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Reporte no encontrado o sin permisos' });
    }
    res.json({ message: 'Reporte eliminado exitosamente' });
  });
});

module.exports = router;

