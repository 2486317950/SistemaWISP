const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../database');
const { JWT_SECRET } = require('../middleware/auth');
const { loginLimiter } = require('../middleware/security');
const { logAudit } = require('../lib/audit');
const { validatePassword } = require('../lib/passwordPolicy');
const { getClientIp } = require('../utils/requestUtils');
const logger = require('../lib/logger');

const router = express.Router();

// Login (con rate limit anti brute-force: 10 intentos / 15 min)
router.post('/login', loginLimiter, (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Usuario y contraseña requeridos' });
  }

  try {
    const database = db.getDb();
    
    if (!database) {
      console.error('Error: Base de datos no inicializada');
      return res.status(503).json({ 
        error: 'Servicio no disponible. La base de datos aún se está inicializando. Por favor, espera unos segundos e intenta nuevamente.' 
      });
    }
    
      database.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
      if (err) {
        logger.error('Error en login (database):', err.message, err);
        // Si el error es porque la base de datos no está lista, devolver 503
        if (err.message && err.message.includes('database') || err.message && err.message.includes('not ready')) {
          return res.status(503).json({ 
            error: 'Servicio no disponible. La base de datos aún se está inicializando. Por favor, espera unos segundos e intenta nuevamente.' 
          });
        }
        return res.status(500).json({ error: 'Error del servidor. Intenta más tarde.' });
      }

      if (!user) {
        console.log(`Intento de login fallido: Usuario "${username}" no encontrado`);
        logAudit('login_fail', { username, details: 'usuario_no_encontrado', ipAddress: getClientIp(req) });
        // Verificar si hay usuarios en la base de datos
        database.all('SELECT id, username, role FROM users', (err, allUsers) => {
          if (!err && allUsers) {
            console.log(`Usuarios existentes en la base de datos: ${allUsers.length}`);
            allUsers.forEach(u => {
              console.log(`  - ID: ${u.id}, Username: ${u.username}, Rol: ${u.role}`);
            });
          }
        });
        
        return res.status(401).json({ error: 'Credenciales inválidas' });
      }
      
      console.log(`Usuario encontrado: ${user.username} (ID: ${user.id}, Rol: ${user.role})`);
      console.log(`Hash de contraseña: ${user.password ? user.password.substring(0, 20) + '...' : 'NULL'}`);

      try {
        // Verificar que la contraseña del usuario no esté vacía o undefined
        if (!user.password) {
          console.error('Error: Usuario sin contraseña en la base de datos');
          return res.status(500).json({ error: 'Error del servidor: Usuario sin contraseña válida' });
        }
        
        // Limpiar espacios en blanco de la contraseña ingresada
        const cleanPassword = password.trim();
        
        // Verificar si la contraseña almacenada es un hash de bcrypt (debe empezar con $2a$, $2b$, o $2y$)
        const isBcryptHash = user.password.startsWith('$2a$') || user.password.startsWith('$2b$') || user.password.startsWith('$2y$');
        
        let validPassword = false;
        
        if (isBcryptHash) {
          // La contraseña está hasheada con bcrypt, usar compare
          validPassword = await bcrypt.compare(cleanPassword, user.password);
        } else {
          // La contraseña no está hasheada (puede ser texto plano por error)
          // Comparar directamente (solo para debugging, debería estar hasheada)
          console.warn(`⚠️ ADVERTENCIA: Usuario "${username}" tiene contraseña sin hashear. Esto es inseguro.`);
          validPassword = cleanPassword === user.password;
          
          // Si la comparación directa funciona, re-hashear la contraseña
          if (validPassword) {
            const hashedPassword = await bcrypt.hash(cleanPassword, 10);
            database.run('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, user.id], (err) => {
              if (err) {
                console.error('Error al actualizar contraseña:', err);
              } else {
                console.log(`✅ Contraseña del usuario "${username}" actualizada a formato bcrypt`);
              }
            });
          }
        }
        
        if (!validPassword) {
          console.log(`Intento de login fallido: Contraseña incorrecta para usuario "${username}"`);
          console.log(`Debug: Usuario encontrado: ${user.username}, Rol: ${user.role}`);
          console.log(`Debug: Hash de contraseña válido: ${isBcryptHash}`);
          console.log(`Debug: Contraseña ingresada (primeros 3 chars): ${cleanPassword.substring(0, 3)}***`);
          console.log(`Debug: Hash almacenado (primeros 20 chars): ${user.password.substring(0, 20)}...`);
          
          // Intentar verificar si el problema es con el hash
          if (isBcryptHash) {
            // Verificar si el hash es válido intentando comparar con una contraseña conocida
            try {
              const testHash = await bcrypt.hash('test', 10);
              console.log(`Debug: Test de bcrypt funcionando. Hash de prueba generado: ${testHash.substring(0, 20)}...`);
            } catch (testErr) {
              console.error('Debug: Error al generar hash de prueba:', testErr);
            }
          }
          
          logAudit('login_fail', { userId: user.id, username: user.username, details: 'password_incorrecta', ipAddress: getClientIp(req) });
          return res.status(401).json({ error: 'Credenciales inválidas' });
        }

        if (user.totp_secret) {
          const tempToken = jwt.sign(
            { id: user.id, username: user.username, need_2fa: true },
            JWT_SECRET,
            { expiresIn: '5m' }
          );
          return res.json({ need_2fa: true, temp_token: tempToken, username: user.username });
        }

        const token = jwt.sign({ id: user.id, username: user.username, role: user.role || 'viewer' }, JWT_SECRET, { expiresIn: '24h' });
        console.log(`Login exitoso: Usuario "${username}" (rol: ${user.role || 'viewer'})`);
        logAudit('login_ok', { userId: user.id, username: user.username, ipAddress: getClientIp(req) });
        res.json({ token, user: { id: user.id, username: user.username, role: user.role || 'viewer' } });
      } catch (bcryptError) {
        console.error('Error en bcrypt:', bcryptError);
        console.error('Error details:', bcryptError.message);
        return res.status(500).json({ error: 'Error al verificar contraseña: ' + bcryptError.message });
      }
    });
  } catch (error) {
    logger.error('Error en login:', error.message, error);
    return res.status(500).json({ error: 'Error del servidor. Intenta más tarde.' });
  }
});

// Cambiar contraseña del usuario actual
const { authenticateToken } = require('../middleware/auth');

router.post('/change-password', authenticateToken, async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  const userId = req.user.id;

  if (!oldPassword || !newPassword) {
    return res.status(400).json({ error: 'Contraseña actual y nueva contraseña son requeridas' });
  }

  const policy = validatePassword(newPassword);
  if (!policy.valid) {
    return res.status(400).json({ error: policy.error });
  }

  const database = db.getDb();
  database.get('SELECT * FROM users WHERE id = ?', [userId], async (err, user) => {
    if (err) {
      return res.status(500).json({ error: 'Error del servidor' });
    }

    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    const validPassword = await bcrypt.compare(oldPassword, user.password);
    if (!validPassword) {
      logAudit('password_change_fail', { userId, username: user.username, details: 'contraseña_actual_incorrecta', ipAddress: getClientIp(req) });
      return res.status(401).json({ error: 'Contraseña actual incorrecta' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    database.run('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, userId], (err) => {
      if (err) {
        return res.status(500).json({ error: 'Error al actualizar la contraseña' });
      }
      logAudit('password_change', { userId, username: user.username, entityType: 'user', entityId: userId, ipAddress: getClientIp(req) });
      res.json({ message: 'Contraseña actualizada exitosamente' });
    });
  });
});

// Cambiar nombre de usuario del usuario actual
router.put('/change-username', authenticateToken, async (req, res) => {
  const { newUsername } = req.body;
  const userId = req.user.id;

  if (!newUsername) {
    return res.status(400).json({ error: 'Nuevo nombre de usuario es requerido' });
  }

  const database = db.getDb();
  // Verificar que el nuevo username no esté en uso
  database.get('SELECT * FROM users WHERE username = ? AND id != ?', [newUsername, userId], async (err, existingUser) => {
    if (err) {
      return res.status(500).json({ error: 'Error del servidor' });
    }

    if (existingUser) {
      return res.status(400).json({ error: 'El nombre de usuario ya está en uso' });
    }

    database.run('UPDATE users SET username = ? WHERE id = ?', [newUsername, userId], (err) => {
      if (err) {
        return res.status(500).json({ error: 'Error al actualizar el nombre de usuario' });
      }
      res.json({ message: 'Nombre de usuario actualizado exitosamente', username: newUsername });
    });
  });
});

// Obtener información del usuario actual
router.get('/me', authenticateToken, (req, res) => {
  const database = db.getDb();
  database.get('SELECT id, username, role, created_at FROM users WHERE id = ?', [req.user.id], (err, user) => {
    if (err) {
      return res.status(500).json({ error: 'Error del servidor' });
    }
    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    res.json(user);
  });
});

// Ruta de utilidad para restablecer contraseña del admin (solo para debugging/emergencias)
// DESHABILITADA en producción por seguridad
router.post('/reset-admin-password', async (req, res) => {
  if (process.env.NODE_ENV === 'production') {
    return res.status(404).json({ error: 'Ruta no encontrada' });
  }
  const { newPassword, username } = req.body;
  
  if (!newPassword) {
    return res.status(400).json({ error: 'Nueva contraseña requerida' });
  }

  try {
    const database = db.getDb();
    
    // Buscar usuario admin o por username si se proporciona
    const searchUsername = username || 'admin';
    database.get('SELECT * FROM users WHERE username = ?', [searchUsername], async (err, adminUser) => {
      if (err) {
        console.error('Error al buscar usuario:', err);
        return res.status(500).json({ error: 'Error al buscar usuario: ' + err.message });
      }
      
      if (!adminUser) {
        // Listar todos los usuarios disponibles
        database.all('SELECT id, username, role FROM users', (err, allUsers) => {
          if (err) {
            return res.status(404).json({ error: `Usuario "${searchUsername}" no encontrado` });
          }
          return res.status(404).json({ 
            error: `Usuario "${searchUsername}" no encontrado`,
            availableUsers: allUsers.map(u => ({ id: u.id, username: u.username, role: u.role }))
          });
        });
        return;
      }
      
      try {
        // Hashear la nueva contraseña
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        console.log(`Restableciendo contraseña para usuario: ${adminUser.username} (ID: ${adminUser.id})`);
        console.log(`Nuevo hash generado: ${hashedPassword.substring(0, 30)}...`);
        
        // Actualizar la contraseña
        database.run('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, adminUser.id], (err) => {
          if (err) {
            console.error('Error al actualizar contraseña:', err);
            return res.status(500).json({ error: 'Error al actualizar la contraseña: ' + err.message });
          }
          
          console.log(`✅ Contraseña del usuario "${adminUser.username}" restablecida exitosamente`);
          res.json({ 
            message: `Contraseña del usuario "${adminUser.username}" restablecida exitosamente`,
            username: adminUser.username,
            id: adminUser.id
          });
        });
      } catch (hashError) {
        console.error('Error al hashear contraseña:', hashError);
        return res.status(500).json({ error: 'Error al hashear la contraseña: ' + hashError.message });
      }
    });
  } catch (error) {
    console.error('Error en reset-admin-password:', error);
    return res.status(500).json({ error: 'Error del servidor: ' + error.message });
  }
});

// --- 2FA (TOTP) --- (carga perezosa para que el servidor arranque aunque falten módulos en el entorno)
let _speakeasy, _QRCode;
function getSpeakeasy() {
  if (_speakeasy === undefined) { try { _speakeasy = require('speakeasy'); } catch (e) { _speakeasy = null; } }
  return _speakeasy;
}
function getQRCode() {
  if (_QRCode === undefined) { try { _QRCode = require('qrcode'); } catch (e) { _QRCode = null; } }
  return _QRCode;
}
const has2FA = () => getSpeakeasy() && getQRCode();

router.post('/2fa/verify-login', loginLimiter, (req, res) => {
  if (!has2FA()) return res.status(503).json({ error: '2FA no disponible en este servidor' });
  const { temp_token, code } = req.body || {};
  if (!temp_token || !code) {
    return res.status(400).json({ error: 'Se requiere temp_token y code' });
  }
  try {
    const decoded = jwt.verify(temp_token, JWT_SECRET);
    if (!decoded.need_2fa || !decoded.id) {
      return res.status(400).json({ error: 'Token inválido para 2FA' });
    }
    const database = db.getDb();
    database.get('SELECT id, username, role, totp_secret FROM users WHERE id = ?', [decoded.id], (err, user) => {
      if (err || !user || !user.totp_secret) {
        return res.status(401).json({ error: 'Usuario o 2FA no configurado' });
      }
      const valid = getSpeakeasy().totp.verify({
        secret: user.totp_secret,
        encoding: 'base32',
        token: String(code).replace(/\s/g, ''),
        window: 1
      });
      if (!valid) {
        logAudit('login_fail', { userId: user.id, username: user.username, details: 'codigo_2fa_invalido', ipAddress: getClientIp(req) });
        return res.status(401).json({ error: 'Código 2FA incorrecto' });
      }
      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role || 'viewer' },
        JWT_SECRET,
        { expiresIn: '24h' }
      );
      logAudit('login_ok', { userId: user.id, username: user.username, ipAddress: getClientIp(req) });
      res.json({ token, user: { id: user.id, username: user.username, role: user.role || 'viewer' } });
    });
  } catch (e) {
    return res.status(401).json({ error: 'Token expirado o inválido' });
  }
});

router.get('/2fa/setup', authenticateToken, (req, res) => {
  if (!has2FA()) return res.status(503).json({ error: '2FA no disponible en este servidor' });
  const database = db.getDb();
  database.get('SELECT id, username, totp_secret FROM users WHERE id = ?', [req.user.id], async (err, user) => {
    if (err || !user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    if (user.totp_secret) {
      return res.json({ enabled: true, message: '2FA ya está activado' });
    }
    const secret = getSpeakeasy().generateSecret({ name: `SistemaWISP (${user.username})`, length: 20 });
    const otpauth = secret.otpauth_url;
    let qr_url = null;
    try {
      qr_url = await getQRCode().toDataURL(otpauth);
    } catch (_) {}
    res.json({ secret: secret.base32, qr_url, otpauth });
  });
});

router.post('/2fa/enable', authenticateToken, (req, res) => {
  if (!has2FA()) return res.status(503).json({ error: '2FA no disponible en este servidor' });
  const { secret, code } = req.body || {};
  if (!secret || !code) {
    return res.status(400).json({ error: 'Se requiere secret y code' });
  }
  const valid = getSpeakeasy().totp.verify({
    secret: secret.trim(),
    encoding: 'base32',
    token: String(code).replace(/\s/g, ''),
    window: 1
  });
  if (!valid) {
    return res.status(400).json({ error: 'Código incorrecto. Verifica la hora de tu dispositivo.' });
  }
  const database = db.getDb();
  database.run('UPDATE users SET totp_secret = ? WHERE id = ?', [secret.trim(), req.user.id], (err) => {
    if (err) {
      return res.status(500).json({ error: 'Error al guardar 2FA' });
    }
    logAudit('2fa_enable', { userId: req.user.id, username: req.user.username, ipAddress: getClientIp(req) });
    res.json({ message: '2FA activado correctamente' });
  });
});

router.post('/2fa/disable', authenticateToken, (req, res) => {
  if (!has2FA()) return res.status(503).json({ error: '2FA no disponible en este servidor' });
  const { password } = req.body || {};
  if (!password) {
    return res.status(400).json({ error: 'Contraseña requerida para desactivar 2FA' });
  }
  const database = db.getDb();
  database.get('SELECT id, username, password, totp_secret FROM users WHERE id = ?', [req.user.id], async (err, user) => {
    if (err || !user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    if (!user.totp_secret) {
      return res.json({ message: '2FA no estaba activado' });
    }
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(401).json({ error: 'Contraseña incorrecta' });
    }
    database.run('UPDATE users SET totp_secret = NULL WHERE id = ?', [req.user.id], (err) => {
      if (err) {
        return res.status(500).json({ error: 'Error al desactivar 2FA' });
      }
      logAudit('2fa_disable', { userId: req.user.id, username: req.user.username, ipAddress: getClientIp(req) });
      res.json({ message: '2FA desactivado' });
    });
  });
});

router.get('/2fa/status', authenticateToken, (req, res) => {
  if (!has2FA()) return res.status(503).json({ error: '2FA no disponible en este servidor' });
  const database = db.getDb();
  database.get('SELECT totp_secret FROM users WHERE id = ?', [req.user.id], (err, row) => {
    if (err || !row) {
      return res.status(500).json({ error: 'Error al consultar estado' });
    }
    res.json({ enabled: !!row.totp_secret });
  });
});

// Ruta de utilidad para listar usuarios (solo para debugging)
// DESHABILITADA en producción por seguridad
router.get('/debug/users', async (req, res) => {
  if (process.env.NODE_ENV === 'production') {
    return res.status(404).json({ error: 'Ruta no encontrada' });
  }
  try {
    const database = db.getDb();
    database.all('SELECT id, username, role, created_at FROM users', (err, users) => {
      if (err) {
        return res.status(500).json({ error: 'Error al obtener usuarios: ' + err.message });
      }
      
      res.json({ 
        users: users.map(u => ({
          id: u.id,
          username: u.username,
          role: u.role,
          created_at: u.created_at,
          hasPassword: true // No exponer el hash
        })),
        count: users.length
      });
    });
  } catch (error) {
    return res.status(500).json({ error: 'Error del servidor: ' + error.message });
  }
});

module.exports = router;

