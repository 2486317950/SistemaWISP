const express = require('express');
const jwt = require('jsonwebtoken');
const db = require('../database');
const { authenticateToken, JWT_SECRET } = require('../middleware/auth');
const { checkPermission } = require('../middleware/permissions');
const { emitEntityUpdate, emitPortalBlockCleared } = require('../socket');
const blockTechnicians = require('../middleware/blockTechnicians');
const { sendPushToClient } = require('../services/pushService');
const { logAudit } = require('../lib/audit');
const { validatePortalPassword } = require('../lib/passwordPolicy');
const { getClientIp } = require('../utils/requestUtils');
const logger = require('../lib/logger');

const router = express.Router();

// Todas las rutas requieren autenticación
router.use(authenticateToken);
// Bloquear acceso de técnicos a clientes
router.use(blockTechnicians);

// Validar código de desbloqueo (ver cliente sin consumir el código)
router.get('/validate-unlock-code', (req, res) => {
  const code = req.query.code;
  if (!code || typeof code !== 'string') {
    return res.status(400).json({ error: 'Código requerido' });
  }
  const database = db.getDb();
  database.get(
    `SELECT b.id, b.client_id, b.expires_at, c.client_number, c.name
     FROM portal_login_blocks b
     LEFT JOIN clients c ON b.client_id = c.id
     WHERE b.unlock_code = ?`,
    [code.trim().toUpperCase()],
    (err, row) => {
      if (err) return res.status(500).json({ error: 'Error del servidor' });
      if (!row) return res.json({ valid: false });
      const now = new Date().toISOString();
      if (row.expires_at && row.expires_at < now) {
        return res.json({ valid: false, expired: true });
      }
      res.json({
        valid: true,
        client_number: row.client_number || null,
        client_name: row.name || null
      });
    }
  );
});

// Desbloquear portal del cliente con código (tras 3 intentos fallidos)
router.post('/unlock-portal', (req, res) => {
  const { code, action } = req.body;
  if (!code || typeof code !== 'string') {
    return res.status(400).json({ error: 'Código de desbloqueo requerido' });
  }
  const act = (action || 'reset').toLowerCase();
  if (act !== 'reset' && act !== 'login') {
    return res.status(400).json({ error: 'action debe ser "reset" o "login"' });
  }

  const database = db.getDb();
  database.get(
    'SELECT id, ip, client_id, expires_at FROM portal_login_blocks WHERE unlock_code = ?',
    [code.trim().toUpperCase()],
    (err, block) => {
      if (err) return res.status(500).json({ error: 'Error del servidor' });
      if (!block) return res.status(404).json({ error: 'Código no válido o ya usado' });

      const now = new Date().toISOString();
      if (block.expires_at && block.expires_at < now) {
        return res.status(400).json({ error: 'El código ha expirado' });
      }

      if (act === 'reset') {
        const clientIdForPush = block.client_id;
        const blockIp = block.ip;
        database.run('DELETE FROM portal_login_attempts WHERE ip = ?', [blockIp], () => {});
        database.run('DELETE FROM portal_login_blocks WHERE id = ?', [block.id], () => {});
        if (clientIdForPush) {
          sendPushToClient(
            clientIdForPush,
            'Contador desbloqueado',
            'Ya puedes intentar iniciar sesión de nuevo. Abre la app.',
            '/portal'
          );
        }
        emitPortalBlockCleared(blockIp);
        return res.json({ message: 'Desbloqueado. El cliente puede intentar de nuevo.' });
      }

      if (act === 'login') {
        if (!block.client_id) {
          return res.status(400).json({ error: 'No se puede iniciar sesión: no se identificó al cliente' });
        }
        database.get('SELECT id, name, client_number FROM clients WHERE id = ?', [block.client_id], (e, client) => {
          if (e || !client) return res.status(404).json({ error: 'Cliente no encontrado' });
          const token = jwt.sign(
            { clientId: client.id, type: 'client_portal', mustChangePassword: true },
            JWT_SECRET,
            { expiresIn: '1h' }
          );
          database.run('DELETE FROM portal_login_attempts WHERE ip = ?', [block.ip], () => {});
          database.run('DELETE FROM portal_login_blocks WHERE id = ?', [block.id], () => {});

          database.get('SELECT 1 FROM client_fcm_tokens WHERE client_id = ?', [client.id], (errFcm, rowFcm) => {
            if (rowFcm) {
              sendPushToClient(
                client.id,
                'Acceso autorizado',
                'El personal autorizó tu acceso. Abre la app para establecer tu nueva contraseña.',
                '/portal',
                token
              );
            }
            res.json({
              message: rowFcm
                ? `Se envió notificación al cliente ${client.client_number}. Debe abrir la app del portal para establecer su nueva contraseña.`
                : `Cliente ${client.client_number} autorizado. El cliente debe tener la app instalada y haber iniciado sesión antes para recibir la notificación push.`,
              client: { id: client.id, name: client.name, client_number: client.client_number }
            });
          });
        });
      }
    }
  );
});

// Probar notificación push (para diagnóstico)
router.post('/test-push', (req, res) => {
  const { clientId } = req.body;
  if (!clientId) {
    return res.status(400).json({ error: 'clientId es requerido' });
  }
  const database = db.getDb();
  database.get('SELECT token FROM client_fcm_tokens WHERE client_id = ?', [clientId], (err, row) => {
    if (err) return res.status(500).json({ error: 'Error al consultar token' });
    if (!row?.token) {
      return res.status(404).json({ error: 'Cliente sin token FCM registrado. Debe iniciar sesión desde la app.' });
    }
    sendPushToClient(parseInt(clientId), 'Prueba', 'Esta es una notificación de prueba del portal.', '/portal');
    res.json({ message: 'Push enviado. Revisa la consola del servidor para ver el resultado.' });
  });
});

// Obtener todos los clientes
router.get('/', (req, res) => {
  const database = db.getDb();
  database.all(`
    SELECT c.*, p.name as package_name, p.speed, p.price as package_price
    FROM clients c
    LEFT JOIN packages p ON c.package_id = p.id
    ORDER BY c.created_at DESC
  `, (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Error al obtener clientes' });
    }
    res.json(rows);
  });
});

// Obtener un cliente por ID
router.get('/:id', (req, res) => {
  const database = db.getDb();
  const clientId = req.params.id;

  database.get(`
    SELECT c.*, p.name as package_name, p.speed, p.price as package_price, p.description as package_description
    FROM clients c
    LEFT JOIN packages p ON c.package_id = p.id
    WHERE c.id = ?
  `, [clientId], (err, client) => {
    if (err) {
      return res.status(500).json({ error: 'Error al obtener el cliente' });
    }
    if (!client) {
      return res.status(404).json({ error: 'Cliente no encontrado' });
    }

    // Obtener pagos del cliente
    database.all('SELECT * FROM payments WHERE client_id = ? ORDER BY payment_date DESC', [clientId], (err, payments) => {
      if (err) {
        return res.status(500).json({ error: 'Error al obtener pagos' });
      }

      // Obtener instalaciones del cliente
      database.all(`
        SELECT i.*, 
               p.name as package_name,
               p.speed as package_speed,
               p.price as package_price
        FROM installations i
        LEFT JOIN packages p ON i.package_id = p.id
        WHERE i.client_id = ? 
        ORDER BY i.installation_date DESC
      `, [clientId], (err, installations) => {
        if (err) {
          return res.status(500).json({ error: 'Error al obtener instalaciones' });
        }

        // Obtener folios del cliente
        database.all('SELECT * FROM folios WHERE client_id = ? ORDER BY visit_date DESC', [clientId], (err, folios) => {
          if (err) {
            return res.status(500).json({ error: 'Error al obtener folios' });
          }

          res.json({
            ...client,
            payments,
            installations,
            folios
          });
        });
      });
    });
  });
});

// Crear un nuevo cliente (todos los roles pueden crear)
router.post('/', checkPermission('create'), (req, res) => {
  const { client_number, name, address, phone, email, network_type, package_id, notes, ip_address } = req.body;

  if (!name || !address) {
    return res.status(400).json({ error: 'Nombre y domicilio son requeridos' });
  }

  const database = db.getDb();
  
  // Convertir package_id a número o null
  const packageId = package_id && package_id !== '' ? parseInt(package_id) : null;
  
  database.run(
    'INSERT INTO clients (client_number, name, address, phone, email, network_type, package_id, notes, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [
      client_number && client_number.trim() !== '' ? client_number.trim() : null,
      name.trim(),
      address.trim(),
      phone && phone.trim() !== '' ? phone.trim() : null,
      email && email.trim() !== '' ? email.trim() : null,
      network_type && network_type.trim() !== '' ? network_type.trim() : null,
      packageId,
      notes && notes.trim() !== '' ? notes.trim() : null,
      ip_address && ip_address.trim() !== '' ? ip_address.trim() : null
    ],
    function(err) {
      if (err) {
        logger.error('Error al crear cliente:', err.message, err);
        if (err.message && err.message.includes('UNIQUE constraint failed')) {
          return res.status(400).json({ error: 'El número de cliente ya está en uso' });
        }
        if (err.message && err.message.includes('no such column')) {
          return res.status(500).json({ error: 'Error en la base de datos. Por favor, reinicia el servidor para actualizar la estructura.' });
        }
        return res.status(500).json({ error: 'Error al crear el cliente. Intenta de nuevo.' });
      }
      
      // Emitir evento de creación en tiempo real
      emitEntityUpdate('clients', 'created', { id: this.lastID });
      
      res.status(201).json({ id: this.lastID, message: 'Cliente creado exitosamente' });
    }
  );
});

// Generar código de restablecimiento de contraseña del portal (para que el cliente use en "Olvidé mi contraseña")
router.post('/:id/generate-portal-reset-code', checkPermission('update'), (req, res) => {
  const database = db.getDb();
  const clientId = req.params.id;
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  const expiresAt = new Date(Date.now() + 60 * 60 * 1000).toISOString(); // 1 hora
  database.get('SELECT id, client_number, name FROM clients WHERE id = ?', [clientId], (err, client) => {
    if (err || !client) return res.status(404).json({ error: 'Cliente no encontrado' });
    database.run(
      'INSERT INTO portal_password_resets (client_id, code, expires_at) VALUES (?, ?, ?)',
      [clientId, code, expiresAt],
      function(insErr) {
        if (insErr) return res.status(500).json({ error: 'Error al generar código' });
        res.json({
          code,
          expires_at: expiresAt,
          message: 'Código válido por 1 hora. Entregar al cliente para que use en "Olvidé mi contraseña".',
          client_number: client.client_number
        });
      }
    );
  });
});

// Configurar acceso al portal del cliente (solo editor y admin)
router.post('/:id/portal-setup', checkPermission('update'), async (req, res) => {
  const { portal_enabled, portal_password } = req.body;
  const clientId = req.params.id;

  const database = db.getDb();
  const bcrypt = require('bcryptjs');

  database.get('SELECT id FROM clients WHERE id = ?', [clientId], async (err, client) => {
    if (err || !client) {
      return res.status(404).json({ error: 'Cliente no encontrado' });
    }

    const enabled = portal_enabled === true || portal_enabled === 1 || portal_enabled === '1' ? 1 : 0;
    let hashedPassword = null;

    if (portal_password) {
      const policy = validatePortalPassword(portal_password, { minLength: 6 });
      if (!policy.valid) {
        return res.status(400).json({ error: policy.error });
      }
      hashedPassword = await bcrypt.hash(portal_password.trim(), 10);
    }

    database.run(
      'UPDATE clients SET portal_enabled = ?, portal_password = COALESCE(?, portal_password) WHERE id = ?',
      [enabled, hashedPassword, clientId],
      function(updateErr) {
        if (updateErr) {
          return res.status(500).json({ error: 'Error al configurar portal' });
        }
        emitEntityUpdate('clients', 'updated', { id: clientId });
        res.json({
          message: 'Portal configurado exitosamente',
          portal_enabled: enabled === 1,
          password_set: !!hashedPassword
        });
      }
    );
  });
});

// Actualizar un cliente (solo editor y admin)
router.put('/:id', checkPermission('update'), (req, res) => {
  const { client_number, name, address, phone, email, network_type, package_id, notes, ip_address } = req.body;
  const clientId = req.params.id;

  if (!name || !address) {
    return res.status(400).json({ error: 'Nombre y domicilio son requeridos' });
  }

  const database = db.getDb();
  // Verificar que el número de cliente no esté en uso por otro cliente
  if (client_number) {
    database.get('SELECT * FROM clients WHERE client_number = ? AND id != ?', [client_number, clientId], (err, existing) => {
      if (err) {
        return res.status(500).json({ error: 'Error del servidor' });
      }
      if (existing) {
        return res.status(400).json({ error: 'El número de cliente ya está en uso' });
      }
      updateClient();
    });
  } else {
    updateClient();
  }

  function updateClient() {
    // Convertir package_id a número o null
    const packageId = package_id && package_id !== '' ? parseInt(package_id) : null;
    
    database.run(
      'UPDATE clients SET client_number = ?, name = ?, address = ?, phone = ?, email = ?, network_type = ?, package_id = ?, notes = ?, ip_address = ? WHERE id = ?',
      [
        client_number && client_number.trim() !== '' ? client_number.trim() : null,
        name.trim(),
        address.trim(),
        phone && phone.trim() !== '' ? phone.trim() : null,
        email && email.trim() !== '' ? email.trim() : null,
        network_type && network_type.trim() !== '' ? network_type.trim() : null,
        packageId,
        notes && notes.trim() !== '' ? notes.trim() : null,
        ip_address && ip_address.trim() !== '' ? ip_address.trim() : null,
        clientId
      ],
      function(err) {
        if (err) {
          logger.error('Error al actualizar cliente:', err.message, err);
          if (err.message && err.message.includes('UNIQUE constraint failed')) {
            return res.status(400).json({ error: 'El número de cliente ya está en uso' });
          }
          if (err.message && err.message.includes('no such column')) {
            return res.status(500).json({ error: 'Error en la base de datos. Por favor, reinicia el servidor para actualizar la estructura.' });
          }
          return res.status(500).json({ error: 'Error al actualizar el cliente. Intenta de nuevo.' });
        }
        if (this.changes === 0) {
          return res.status(404).json({ error: 'Cliente no encontrado' });
        }
        
        // Emitir evento de actualización en tiempo real
        emitEntityUpdate('clients', 'updated', { id: clientId });
        
        res.json({ message: 'Cliente actualizado exitosamente' });
      }
    );
  }
});

// Eliminar un cliente (solo admin) - Elimina automáticamente todos los registros relacionados
router.delete('/:id', checkPermission('delete'), (req, res) => {
  const database = db.getDb();
  const clientId = req.params.id;

  // Función auxiliar para eliminar registros de una tabla
  const deleteFromTable = (tableName, clientIdField = 'client_id') => {
    return new Promise((resolve, reject) => {
      database.run(`DELETE FROM ${tableName} WHERE ${clientIdField} = ?`, [clientId], function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.changes);
        }
      });
    });
  };

  // Función auxiliar para eliminar items de cotizaciones
  const deleteQuotationItems = () => {
    return new Promise((resolve, reject) => {
      // Primero obtener los IDs de las cotizaciones del cliente
      database.all('SELECT id FROM quotations WHERE client_id = ?', [clientId], (err, quotations) => {
        if (err) {
          reject(err);
          return;
        }
        
        if (quotations.length === 0) {
          resolve(0);
          return;
        }
        
        const quotationIds = quotations.map(q => q.id);
        const placeholders = quotationIds.map(() => '?').join(',');
        
        database.run(`DELETE FROM quotation_items WHERE quotation_id IN (${placeholders})`, quotationIds, function(err) {
          if (err) {
            reject(err);
          } else {
            resolve(this.changes);
          }
        });
      });
    });
  };

  // Verificar que el cliente existe
  database.get('SELECT id FROM clients WHERE id = ?', [clientId], (err, client) => {
    if (err) {
      return res.status(500).json({ error: 'Error al verificar el cliente' });
    }
    
    if (!client) {
      return res.status(404).json({ error: 'Cliente no encontrado' });
    }

    // Eliminar todos los registros relacionados en orden
    Promise.all([
      deleteQuotationItems().catch(() => 0), // Eliminar items de cotizaciones primero
      deleteFromTable('quotation_items').catch(() => 0), // Por si acaso hay items huérfanos
      deleteFromTable('quotations').catch(() => 0), // Eliminar cotizaciones
      deleteFromTable('receipts').catch(() => 0), // Eliminar recibos
      deleteFromTable('payments').catch(() => 0), // Eliminar pagos
      deleteFromTable('installations').catch(() => 0), // Eliminar instalaciones
      deleteFromTable('folios').catch(() => 0) // Eliminar folios
    ]).then(() => {
      // Finalmente, eliminar el cliente
      database.run('DELETE FROM clients WHERE id = ?', [clientId], function(err) {
        if (err) {
          logger.error('Error al eliminar cliente:', err.message, err);
          return res.status(500).json({ error: 'Error al eliminar el cliente. Intenta de nuevo.' });
        }
        
        if (this.changes === 0) {
          return res.status(404).json({ error: 'Cliente no encontrado' });
        }
        logAudit('client_delete', {
          userId: req.user?.id,
          username: req.user?.username,
          entityType: 'client',
          entityId: clientId,
          ipAddress: getClientIp(req)
        });
        // Emitir evento de eliminación en tiempo real
        emitEntityUpdate('clients', 'deleted', { id: clientId });
        
        res.json({ 
          message: 'Cliente y todos sus registros relacionados eliminados exitosamente',
          deleted: {
            client: 1,
            payments: 'eliminados',
            installations: 'eliminadas',
            folios: 'eliminados',
            receipts: 'eliminados',
            quotations: 'eliminadas'
          }
        });
      });
    }).catch((error) => {
      logger.error('Error al eliminar registros relacionados:', error.message, error);
      return res.status(500).json({ error: 'Error al eliminar registros relacionados. Intenta de nuevo.' });
    });
  });
});

module.exports = router;

