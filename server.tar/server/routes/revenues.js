const express = require('express');
const db = require('../database');
const { authenticateToken } = require('../middleware/auth');
const { checkPermission } = require('../middleware/permissions');
const blockTechnicians = require('../middleware/blockTechnicians');

const router = express.Router();

// Todas las rutas requieren autenticación
router.use(authenticateToken);
// Bloquear acceso de técnicos a ingresos
router.use(blockTechnicians);

// Obtener todos los ingresos (pagos + instalaciones con fee)
router.get('/', (req, res) => {
  const database = db.getDb();
  
  // Obtener pagos
  database.all(`
    SELECT 
      p.id,
      p.payment_date as date,
      p.amount,
      p.receipt_number,
      p.is_free_month,
      p.payment_method,
      p.payment_type,
      p.notes,
      'payment' as revenue_type,
      'Pago Mensual' as revenue_type_label,
      COALESCE(p.custom_name, c.name) as client_name,
      c.client_number,
      COALESCE(p.custom_address, c.address) as client_address,
      NULL as installation_type,
      NULL as installation_status
    FROM payments p
    LEFT JOIN clients c ON p.client_id = c.id
    ORDER BY p.payment_date DESC
  `, (err, payments) => {
    if (err) {
      console.error('Error al obtener pagos:', err);
      return res.status(500).json({ error: 'Error al obtener pagos' });
    }
    
    // Obtener ingresos por instalación (solo las que tienen fee > 0 Y están pagadas)
    database.all(`
      SELECT 
        i.id,
        COALESCE(i.payment_date, i.installation_date) as date,
        i.installation_fee as amount,
        NULL as receipt_number,
        0 as is_free_month,
        i.notes,
        'installation' as revenue_type,
        'Pago por Instalación' as revenue_type_label,
        COALESCE(c.name, i.custom_name) as client_name,
        c.client_number,
        COALESCE(i.address, c.address) as client_address,
        i.installation_type,
        i.status as installation_status,
        i.is_paid,
        i.installation_date,
        i.payment_date
      FROM installations i
      LEFT JOIN clients c ON i.client_id = c.id
      WHERE i.installation_fee > 0 AND i.is_paid = 1
      ORDER BY COALESCE(i.payment_date, i.installation_date) DESC
    `, (err, installations) => {
      if (err) {
        console.error('Error al obtener instalaciones con fee:', err);
        return res.status(500).json({ error: 'Error al obtener instalaciones' });
      }
      
      // Combinar ambos tipos de ingresos
      const allRevenues = [...payments, ...installations];
      
      // Ordenar por fecha (más reciente primero)
      allRevenues.sort((a, b) => new Date(b.date) - new Date(a.date));
      
      res.json(allRevenues);
    });
  });
});

// Obtener resumen de ingresos
router.get('/summary', (req, res) => {
  const database = db.getDb();
  
  // Obtener total de pagos
  database.get(`
    SELECT 
      COALESCE(SUM(p.amount), 0) as total_payments,
      COUNT(p.id) as payment_count,
      COALESCE(SUM(CASE WHEN p.is_free_month = 1 THEN p.amount ELSE 0 END), 0) as free_months_amount,
      COUNT(CASE WHEN p.is_free_month = 1 THEN 1 END) as free_months_count
    FROM payments p
  `, (err, paymentsSummary) => {
    if (err) {
      console.error('Error al obtener resumen de pagos:', err);
      return res.status(500).json({ error: 'Error al obtener resumen de pagos' });
    }
    
    // Obtener total de ingresos por instalación (solo las pagadas)
    database.get(`
      SELECT 
        COALESCE(SUM(i.installation_fee), 0) as total_installations,
        COUNT(CASE WHEN i.installation_fee > 0 AND i.is_paid = 1 THEN 1 END) as installation_count
      FROM installations i
      WHERE i.installation_fee > 0 AND i.is_paid = 1
    `, (err, installationsSummary) => {
      if (err) {
        console.error('Error al obtener resumen de instalaciones:', err);
        return res.status(500).json({ error: 'Error al obtener resumen de instalaciones' });
      }
      
      // Obtener total percibido por red (SOLO pagos de mensualidad, NO instalaciones)
      // El total percibido es la suma de todos los pagos de clientes de esa red
      // Usar p.network_type para pagos de mensualidad (ahora se guarda en payments)
      database.all(`
        SELECT 
          p.network_type as network_type,
          COALESCE(SUM(p.amount), 0) as total_received,
          COALESCE(SUM(CASE WHEN p.is_free_month = 1 THEN p.amount ELSE 0 END), 0) as free_months_amount,
          COUNT(p.id) as payment_count
        FROM payments p
        WHERE p.payment_type = 'mensualidad' 
          AND p.network_type IS NOT NULL 
          AND p.network_type != ''
        GROUP BY p.network_type
      `, (err, revenueByNetwork) => {
        if (err) {
          console.error('Error al obtener ingresos por red:', err);
          return res.status(500).json({ error: 'Error al obtener ingresos por red' });
        }
        
        // Obtener ingresos por instalaciones agrupados por red (solo las que tienen cliente con network_type)
        database.all(`
          SELECT 
            c.network_type,
            COALESCE(SUM(i.installation_fee), 0) as installation_revenue,
            COUNT(i.id) as installation_count
          FROM installations i
          JOIN clients c ON i.client_id = c.id
          WHERE i.installation_fee > 0 AND i.is_paid = 1 
            AND c.network_type IS NOT NULL AND c.network_type != ''
          GROUP BY c.network_type
        `, (err, installationsByNetwork) => {
          if (err) {
            console.error('Error al obtener instalaciones por red:', err);
          }
          
          // Obtener total pagado a proveedores por red
          database.all(`
            SELECT 
              network_type,
              COALESCE(SUM(paid_amount), 0) as total_paid,
              COALESCE(SUM(total_amount), 0) as total_amount
            FROM provider_payments
            GROUP BY network_type
          `, (err, paidByNetwork) => {
            if (err) {
              console.error('Error al obtener pagos a proveedores por red:', err);
              return res.status(500).json({ error: 'Error al obtener pagos a proveedores por red' });
            }
            
            // Obtener instalaciones sin cliente o con cliente sin network_type (para agregar al total general)
            database.get(`
              SELECT 
                COALESCE(SUM(i.installation_fee), 0) as installation_revenue_no_network
              FROM installations i
              LEFT JOIN clients c ON i.client_id = c.id
              WHERE i.installation_fee > 0 AND i.is_paid = 1 
                AND (i.client_id IS NULL OR c.network_type IS NULL OR c.network_type = '')
            `, (err, installationsNoNetwork) => {
              if (err) {
                console.error('Error al obtener instalaciones sin red:', err);
              }
              
              // NUEVA LÓGICA FINANCIERA:
              // 1. Total de Percepciones = Total de Pagos + Instalaciones
              // 2. Ganancia = Total de Percepciones - Gastos - Pagos a Proveedores
              
              // Calcular totales generales (inicializar en 0 con precisión)
              let totalPerceptions = 0.00; // Total de Percepciones = Pagos + Instalaciones
              let totalPaymentsNet = 0.00; // Solo pagos netos (descontando meses gratis)
              let totalInstallations = 0.00; // Total de instalaciones
              let totalPaidToProviders = 0.00;
              const networkStats = [];
              
              // Crear un mapa de pagos a proveedores por red para acceso rápido
              const providerPaymentsMap = {};
              paidByNetwork.forEach(pp => {
                providerPaymentsMap[pp.network_type] = {
                  total_paid: parseFloat(pp.total_paid) || 0,
                  total_amount: parseFloat(pp.total_amount) || 0
                };
              });
              
              // Crear un mapa de instalaciones por red
              const installationsMap = {};
              (installationsByNetwork || []).forEach(inst => {
                installationsMap[inst.network_type] = {
                  installation_revenue: parseFloat(inst.installation_revenue) || 0,
                  installation_count: inst.installation_count || 0
                };
              });
              
              const installationRevenueNoNetwork = parseFloat(installationsNoNetwork?.installation_revenue_no_network) || 0;
              
              // Procesar ingresos por red
              revenueByNetwork.forEach(network => {
                const networkType = network.network_type;
                const totalReceivedNetwork = parseFloat(network.total_received) || 0;
                const freeMonthsAmountNetwork = parseFloat(network.free_months_amount) || 0;
                
                // FÓRMULA: TOTAL DE PAGOS = Suma de todos los pagos de clientes - Meses gratis
                const totalPaymentsNetwork = parseFloat((totalReceivedNetwork - freeMonthsAmountNetwork).toFixed(2));
                
                // Agregar ingresos por instalaciones de esta red
                const installationData = installationsMap[networkType] || { installation_revenue: 0, installation_count: 0 };
                const installationRevenueNetwork = parseFloat(installationData.installation_revenue) || 0;
                
                // FÓRMULA: TOTAL DE PERCEPCIONES POR RED = Total de Pagos + Instalaciones
                const totalPerceptionsNetwork = parseFloat((totalPaymentsNetwork + installationRevenueNetwork).toFixed(2));
                
                // Buscar pagos a proveedores para esta red
                const providerPayment = providerPaymentsMap[networkType] || { total_paid: 0, total_amount: 0 };
                const paidToProviderNetwork = parseFloat(providerPayment.total_paid) || 0;
                
                // Acumular totales (redondeando a 2 decimales en cada suma)
                totalPaymentsNet = parseFloat((totalPaymentsNet + totalPaymentsNetwork).toFixed(2));
                totalInstallations = parseFloat((totalInstallations + installationRevenueNetwork).toFixed(2));
                totalPerceptions = parseFloat((totalPerceptions + totalPerceptionsNetwork).toFixed(2));
                totalPaidToProviders = parseFloat((totalPaidToProviders + paidToProviderNetwork).toFixed(2));
                
                networkStats.push({
                  network_type: networkType,
                  total_payments: totalPaymentsNetwork,
                  installation_revenue: installationRevenueNetwork,
                  total_perceptions: totalPerceptionsNetwork, // Pagos + Instalaciones
                  total_received_gross: parseFloat(totalReceivedNetwork.toFixed(2)),
                  free_months_amount: parseFloat(freeMonthsAmountNetwork.toFixed(2)),
                  payment_count: network.payment_count || 0,
                  installation_count: installationData.installation_count || 0,
                  paid_to_provider: paidToProviderNetwork
                });
              });
              
              // Agregar redes que solo tienen pagos a proveedores pero no ingresos
              paidByNetwork.forEach(providerPayment => {
                const networkType = providerPayment.network_type;
                const exists = networkStats.find(ns => ns.network_type === networkType);
                if (!exists) {
                  const paidToProviderNetwork = parseFloat(providerPayment.total_paid) || 0;
                  
                  totalPaidToProviders = parseFloat((totalPaidToProviders + paidToProviderNetwork).toFixed(2));
                  
                  networkStats.push({
                    network_type: networkType,
                    total_payments: 0,
                    installation_revenue: 0,
                    total_perceptions: 0, // Sin percepciones
                    total_received_gross: 0,
                    free_months_amount: 0,
                    payment_count: 0,
                    installation_count: 0,
                    paid_to_provider: paidToProviderNetwork
                  });
                }
              });
              
              // Obtener pagos sin network_type (para agregar al total sin instalaciones)
              // Incluye pagos de mensualidad sin network_type y pagos personalizados
              database.get(`
                SELECT 
                  COALESCE(SUM(p.amount), 0) as total_payments_no_network,
                  COALESCE(SUM(CASE WHEN p.is_free_month = 1 THEN p.amount ELSE 0 END), 0) as free_months_amount_no_network
                FROM payments p
                LEFT JOIN clients c ON p.client_id = c.id
                WHERE (
                  (p.payment_type = 'mensualidad' AND (p.network_type IS NULL OR p.network_type = ''))
                  OR (p.payment_type = 'instalacion' AND (c.network_type IS NULL OR c.network_type = ''))
                  OR p.payment_type = 'personalizado'
                )
              `, (err, paymentsNoNetwork) => {
                if (err) {
                  console.error('Error al obtener pagos sin red:', err);
                }
                
                const paymentsNoNetworkAmount = parseFloat(paymentsNoNetwork?.total_payments_no_network) || 0;
                const freeMonthsNoNetworkAmount = parseFloat(paymentsNoNetwork?.free_months_amount_no_network) || 0;
                const netPaymentsNoNetwork = parseFloat((paymentsNoNetworkAmount - freeMonthsNoNetworkAmount).toFixed(2));
                
                // Agregar pagos sin red al total de pagos
                totalPaymentsNet = parseFloat((totalPaymentsNet + netPaymentsNoNetwork).toFixed(2));
                
                // Agregar instalaciones sin red al total de instalaciones
                totalInstallations = parseFloat((totalInstallations + installationRevenueNoNetwork).toFixed(2));
                
                // FÓRMULA: TOTAL DE PERCEPCIONES = Total de Pagos + Total de Instalaciones
                totalPerceptions = parseFloat((totalPaymentsNet + totalInstallations).toFixed(2));
              
                const totalPayments = parseFloat(paymentsSummary.total_payments) || 0;
                const freeMonthsAmount = parseFloat(paymentsSummary.free_months_amount) || 0;
                const totalInstallationsAll = parseFloat(installationsSummary.total_installations) || 0;
                
                // Función para procesar los datos de gastos y continuar con el flujo
                function handleExpensesData(totalExpenses, expenseCount) {
                  // Obtener total de transferencias
                  database.get(`
                    SELECT 
                      COALESCE(SUM(amount), 0) as total_transfers,
                      COUNT(id) as transfer_count
                    FROM transfers
                  `, (err, transfersSummary) => {
                    if (err) {
                      console.error('Error al obtener total de transferencias:', err);
                    }
                    
                    const totalTransfers = parseFloat(transfersSummary?.total_transfers) || 0;
                    
                    // NUEVA FÓRMULA: GANANCIA = Total de Percepciones - Gastos - Pagos a Proveedores - Transferencias
                    const totalProfit = parseFloat((totalPerceptions - totalExpenses - totalPaidToProviders - totalTransfers).toFixed(2));
                    
                    // Calcular ganancia por red (sin gastos universales, solo para referencia)
                    networkStats.forEach(network => {
                      // Ganancia por red = Percepciones de la red - Pagos a proveedor de la red
                      // Los gastos son universales y se aplican al total general
                      network.profit = parseFloat((network.total_perceptions - network.paid_to_provider).toFixed(2));
                    });
                    
                    res.json({
                      // Totales básicos
                      total_payments: parseFloat(totalPayments.toFixed(2)),
                      payment_count: paymentsSummary.payment_count || 0,
                      free_months_amount: parseFloat(freeMonthsAmount.toFixed(2)),
                      free_months_count: paymentsSummary.free_months_count || 0,
                      total_installations: parseFloat(totalInstallationsAll.toFixed(2)),
                      installation_count: installationsSummary.installation_count || 0,
                      
                      // NUEVA LÓGICA FINANCIERA
                      total_perceptions: parseFloat(totalPerceptions.toFixed(2)), // Pagos + Instalaciones
                      total_payments_net: parseFloat(totalPaymentsNet.toFixed(2)), // Pagos netos (sin meses gratis)
                      total_expenses: parseFloat(totalExpenses.toFixed(2)),
                      expense_count: expenseCount,
                      total_transfers: parseFloat(totalTransfers.toFixed(2)),
                      transfer_count: transfersSummary?.transfer_count || 0,
                      total_paid_to_providers: parseFloat(totalPaidToProviders.toFixed(2)),
                      
                      // GANANCIA = Total de Percepciones - Gastos - Pagos a Proveedores - Transferencias
                      total_profit: totalProfit,
                      
                      // Mantener compatibilidad con código anterior
                      total_revenue: parseFloat(totalPerceptions.toFixed(2)),
                      total_received_without_installations: parseFloat(totalPaymentsNet.toFixed(2)),
                      total_received_with_installations: parseFloat(totalPerceptions.toFixed(2)),
                      net_revenue_without_installations: totalProfit,
                      net_revenue_with_installations: totalProfit,
                      
                      network_stats: networkStats
                    });
                  });
                }

                // Obtener total de gastos (excluyendo los gastos relacionados con pagos a proveedores,
                // ya que estos se restan por separado como totalPaidToProviders)
                database.get(`
                  SELECT 
                    COALESCE(SUM(amount), 0) as total_expenses,
                    COUNT(id) as expense_count
                  FROM expenses
                  WHERE provider_payment_id IS NULL
                `, (err, expensesSummary) => {
                  if (err) {
                    console.error('Error al obtener total de gastos:', err);
                    // En caso de error, establecer valores por defecto
                    const totalExpenses = 0;
                    const expenseCount = 0;
                    // Continuar con el flujo usando estos valores por defecto
                    return handleExpensesData(totalExpenses, expenseCount);
                  }
                  
                  const totalExpenses = parseFloat(expensesSummary?.total_expenses) || 0;
                  const expenseCount = expensesSummary?.expense_count || 0;
                  
                  handleExpensesData(totalExpenses, expenseCount);
                });
              });
            });
          });
        });
      });
    });
  });
});

// Helper: ejecutar resumen para un mes dado (YYYY-MM)
function runSummaryForMonth(database, currentMonth, res) {
  database.get(`
    SELECT 
      COALESCE(SUM(p.amount), 0) as total_payments,
      COUNT(p.id) as payment_count,
      COALESCE(SUM(CASE WHEN p.is_free_month = 1 THEN p.amount ELSE 0 END), 0) as free_months_amount,
      COUNT(CASE WHEN p.is_free_month = 1 THEN 1 END) as free_months_count
    FROM payments p
    WHERE strftime('%Y-%m', DATE(p.payment_date)) = ?
  `, [currentMonth], (err, paymentsSummary) => {
    if (err) {
      console.error('Error al obtener resumen de pagos del mes:', err);
      return res.status(500).json({ error: 'Error al obtener resumen de pagos del mes' });
    }
    database.get(`
      SELECT 
        COALESCE(SUM(i.installation_fee), 0) as total_installations,
        COUNT(CASE WHEN i.installation_fee > 0 AND i.is_paid = 1 THEN 1 END) as installation_count
      FROM installations i
      WHERE i.installation_fee > 0 
        AND i.is_paid = 1
        AND strftime('%Y-%m', COALESCE(i.payment_date, i.installation_date)) = ?
    `, [currentMonth], (err, installationsSummary) => {
      if (err) {
        console.error('Error al obtener resumen de instalaciones del mes:', err);
        return res.status(500).json({ error: 'Error al obtener resumen de instalaciones del mes' });
      }
      database.get(`
        SELECT 
          COALESCE(SUM(amount), 0) as total_expenses,
          COUNT(id) as expense_count
        FROM expenses
        WHERE strftime('%Y-%m', expense_date) = ?
      `, [currentMonth], (err, expensesSummary) => {
        if (err) {
          console.error('Error al obtener resumen de gastos del mes:', err);
          return res.status(500).json({ error: 'Error al obtener resumen de gastos del mes' });
        }
        database.get(`
          SELECT 
            COALESCE(SUM(paid_amount), 0) as total_paid_to_providers
          FROM provider_payments
          WHERE strftime('%Y-%m', DATE(payment_date)) = ?
        `, [currentMonth], (err, providerPaymentsSummary) => {
          if (err) {
            console.error('Error al obtener resumen de pagos a proveedores del mes:', err);
            return res.status(500).json({ error: 'Error al obtener resumen de pagos a proveedores del mes' });
          }
          database.get(`
            SELECT 
              COALESCE(SUM(amount), 0) as total_transfers
            FROM transfers
            WHERE strftime('%Y-%m', transfer_date) = ?
          `, [currentMonth], (err, transfersSummary) => {
            if (err) {}
            const totalPayments = parseFloat(paymentsSummary?.total_payments || 0);
            const freeMonthsAmount = parseFloat(paymentsSummary?.free_months_amount || 0);
            const totalPaymentsNet = parseFloat((totalPayments - freeMonthsAmount).toFixed(2));
            const totalInstallations = parseFloat(installationsSummary?.total_installations || 0);
            const totalPerceptions = parseFloat((totalPaymentsNet + totalInstallations).toFixed(2));
            const totalExpenses = parseFloat(expensesSummary?.total_expenses || 0);
            const totalPaidToProviders = parseFloat(providerPaymentsSummary?.total_paid_to_providers || 0);
            const totalTransfers = parseFloat(transfersSummary?.total_transfers || 0);
            const totalProfit = parseFloat((totalPerceptions - totalExpenses - totalTransfers).toFixed(2));
            database.get(`
              SELECT COUNT(*) as clients_count
              FROM clients
              WHERE strftime('%Y-%m', created_at) = ?
            `, [currentMonth], (err, clientsRow) => {
              if (err) {}
              database.get(`
                SELECT COUNT(*) as installations_count
                FROM installations
                WHERE strftime('%Y-%m', installation_date) = ?
              `, [currentMonth], (err, installationsCountRow) => {
                if (err) {}
                database.get(`
                  SELECT COUNT(*) as folios_count
                  FROM folios
                  WHERE strftime('%Y-%m', visit_date) = ?
                `, [currentMonth], (err, foliosRow) => {
                  if (err) {}
                  res.json({
                    month: currentMonth,
                    total_payments: totalPayments,
                    total_payments_net: totalPaymentsNet,
                    free_months_amount: freeMonthsAmount,
                    free_months_count: paymentsSummary?.free_months_count || 0,
                    total_installations: totalInstallations,
                    total_perceptions: totalPerceptions,
                    total_expenses: totalExpenses,
                    expense_count: expensesSummary?.expense_count || 0,
                    total_paid_to_providers: totalPaidToProviders,
                    total_transfers: totalTransfers,
                    total_profit: totalProfit,
                    clients_count: clientsRow?.clients_count || 0,
                    payments_count: paymentsSummary?.payment_count || 0,
                    installations_count: installationsCountRow?.installations_count || 0,
                    folios_count: foliosRow?.folios_count || 0
                  });
                });
              });
            });
          });
        });
      });
    });
  });
}

// Resumen por mes (para app inversionista): ?month=YYYY-MM
router.get('/summary/for-month', (req, res) => {
  const database = db.getDb();
  const now = new Date();
  const defaultMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const monthParam = req.query.month;
  const currentMonth = (monthParam && /^\d{4}-\d{2}$/.test(monthParam)) ? monthParam : defaultMonth;
  runSummaryForMonth(database, currentMonth, res);
});

// Obtener resumen del mes actual
router.get('/summary/current-month', (req, res) => {
  const database = db.getDb();
  
  // Obtener el mes actual en formato YYYY-MM (usando fecha local del servidor)
  const now = new Date();
  const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  
  console.log('📅 Consultando pagos del mes:', currentMonth);
  console.log('📅 Fecha actual del servidor:', now.toISOString());
  console.log('📅 Zona horaria del servidor:', Intl.DateTimeFormat().resolvedOptions().timeZone);
  
  // Obtener total de pagos del mes actual
  // Usar DATE() para asegurar que SQLite interprete correctamente la fecha
  database.get(`
    SELECT 
      COALESCE(SUM(p.amount), 0) as total_payments,
      COUNT(p.id) as payment_count,
      COALESCE(SUM(CASE WHEN p.is_free_month = 1 THEN p.amount ELSE 0 END), 0) as free_months_amount,
      COUNT(CASE WHEN p.is_free_month = 1 THEN 1 END) as free_months_count
    FROM payments p
    WHERE strftime('%Y-%m', DATE(p.payment_date)) = ?
  `, [currentMonth], (err, paymentsSummary) => {
    if (err) {
      console.error('Error al obtener resumen de pagos del mes:', err);
      return res.status(500).json({ error: 'Error al obtener resumen de pagos del mes' });
    }
    
    // Obtener total de ingresos por instalación del mes actual (solo las pagadas)
    // Usar payment_date si está disponible, sino usar installation_date
    database.get(`
      SELECT 
        COALESCE(SUM(i.installation_fee), 0) as total_installations,
        COUNT(CASE WHEN i.installation_fee > 0 AND i.is_paid = 1 THEN 1 END) as installation_count
      FROM installations i
      WHERE i.installation_fee > 0 
        AND i.is_paid = 1
        AND strftime('%Y-%m', COALESCE(i.payment_date, i.installation_date)) = ?
    `, [currentMonth], (err, installationsSummary) => {
      if (err) {
        console.error('Error al obtener resumen de instalaciones del mes:', err);
        return res.status(500).json({ error: 'Error al obtener resumen de instalaciones del mes' });
      }
      
      // Obtener total de gastos del mes actual
      database.get(`
        SELECT 
          COALESCE(SUM(amount), 0) as total_expenses,
          COUNT(id) as expense_count
        FROM expenses
        WHERE strftime('%Y-%m', expense_date) = ?
      `, [currentMonth], (err, expensesSummary) => {
        if (err) {
          console.error('Error al obtener resumen de gastos del mes:', err);
          return res.status(500).json({ error: 'Error al obtener resumen de gastos del mes' });
        }
        
        // Obtener total pagado a proveedores del mes actual
        database.get(`
          SELECT 
            COALESCE(SUM(paid_amount), 0) as total_paid_to_providers
          FROM provider_payments
          WHERE strftime('%Y-%m', DATE(payment_date)) = ?
        `, [currentMonth], (err, providerPaymentsSummary) => {
          if (err) {
            console.error('Error al obtener resumen de pagos a proveedores del mes:', err);
            return res.status(500).json({ error: 'Error al obtener resumen de pagos a proveedores del mes' });
          }
          
          // Obtener total de transferencias del mes actual
          database.get(`
            SELECT 
              COALESCE(SUM(amount), 0) as total_transfers
            FROM transfers
            WHERE strftime('%Y-%m', transfer_date) = ?
          `, [currentMonth], (err, transfersSummary) => {
            if (err) {
              console.error('Error al obtener resumen de transferencias del mes:', err);
              // Continuar sin transferencias si hay error
            }
            
            // Calcular totales del mes actual
            const totalPayments = parseFloat(paymentsSummary?.total_payments || 0);
            const freeMonthsAmount = parseFloat(paymentsSummary?.free_months_amount || 0);
            const totalPaymentsNet = parseFloat((totalPayments - freeMonthsAmount).toFixed(2));
            const totalInstallations = parseFloat(installationsSummary?.total_installations || 0);
            const totalPerceptions = parseFloat((totalPaymentsNet + totalInstallations).toFixed(2));
            const totalExpenses = parseFloat(expensesSummary?.total_expenses || 0);
            const totalPaidToProviders = parseFloat(providerPaymentsSummary?.total_paid_to_providers || 0);
            const totalTransfers = parseFloat(transfersSummary?.total_transfers || 0);
            // Los pagos a proveedores ya están incluidos en totalExpenses, no se restan por separado
            const totalProfit = parseFloat((totalPerceptions - totalExpenses - totalTransfers).toFixed(2));
            
            // Obtener contadores del mes actual
            database.get(`
              SELECT COUNT(*) as clients_count
              FROM clients
              WHERE strftime('%Y-%m', created_at) = ?
            `, [currentMonth], (err, clientsRow) => {
              if (err) {
                console.error('Error al obtener contador de clientes del mes:', err);
              }
              
              database.get(`
                SELECT COUNT(*) as installations_count
                FROM installations
                WHERE strftime('%Y-%m', installation_date) = ?
              `, [currentMonth], (err, installationsCountRow) => {
                if (err) {
                  console.error('Error al obtener contador de instalaciones del mes:', err);
                }
                
                database.get(`
                  SELECT COUNT(*) as folios_count
                  FROM folios
                  WHERE strftime('%Y-%m', visit_date) = ?
                `, [currentMonth], (err, foliosRow) => {
                  if (err) {
                    console.error('Error al obtener contador de folios del mes:', err);
                  }
                  
                  // Obtener datos por red del mes actual
                  database.all(`
                    SELECT 
                      p.network_type as network_type,
                      COALESCE(SUM(p.amount), 0) as total_received,
                      COALESCE(SUM(CASE WHEN p.is_free_month = 1 THEN p.amount ELSE 0 END), 0) as free_months_amount,
                      COUNT(p.id) as payment_count
                    FROM payments p
                    WHERE p.payment_type = 'mensualidad' 
                      AND p.network_type IS NOT NULL 
                      AND p.network_type != ''
                      AND strftime('%Y-%m', p.payment_date) = ?
                    GROUP BY p.network_type
                  `, [currentMonth], (err, revenueByNetwork) => {
                    if (err) {
                      console.error('Error al obtener ingresos por red del mes:', err);
                      return res.json({
                        month: currentMonth,
                        total_payments: totalPayments,
                        total_payments_net: totalPaymentsNet,
                        free_months_amount: freeMonthsAmount,
                        free_months_count: paymentsSummary?.free_months_count || 0,
                        total_installations: totalInstallations,
                        total_perceptions: totalPerceptions,
                        total_expenses: totalExpenses,
                        expense_count: expensesSummary?.expense_count || 0,
                        total_paid_to_providers: totalPaidToProviders,
                        total_transfers: totalTransfers,
                        total_profit: totalProfit,
                        clients_count: clientsRow?.clients_count || 0,
                        payments_count: paymentsSummary?.payment_count || 0,
                        installations_count: installationsCountRow?.installations_count || 0,
                        folios_count: foliosRow?.folios_count || 0,
                        network_stats: []
                      });
                    }
                    
                    // Obtener instalaciones por red del mes actual
                    database.all(`
                      SELECT 
                        c.network_type,
                        COALESCE(SUM(i.installation_fee), 0) as installation_revenue,
                        COUNT(i.id) as installation_count
                      FROM installations i
                      JOIN clients c ON i.client_id = c.id
                      WHERE i.installation_fee > 0 
                        AND i.is_paid = 1 
                        AND c.network_type IS NOT NULL 
                        AND c.network_type != ''
                        AND strftime('%Y-%m', i.installation_date) = ?
                      GROUP BY c.network_type
                    `, [currentMonth], (err, installationsByNetwork) => {
                      if (err) {
                        console.error('Error al obtener instalaciones por red del mes:', err);
                      }
                      
                      // Obtener pagos a proveedores por red del mes actual
                      database.all(`
                        SELECT 
                          network_type,
                          COALESCE(SUM(paid_amount), 0) as total_paid
                        FROM provider_payments
                        WHERE strftime('%Y-%m', DATE(payment_date)) = ?
                        GROUP BY network_type
                      `, [currentMonth], (err, paidByNetwork) => {
                        if (err) {
                          console.error('Error al obtener pagos a proveedores por red del mes:', err);
                        }
                        
                        // Combinar datos por red
                        const networkStatsMap = {};
                        
                        revenueByNetwork.forEach(network => {
                          networkStatsMap[network.network_type] = {
                            network_type: network.network_type,
                            total_received_gross: parseFloat(network.total_received || 0),
                            free_months_amount: parseFloat(network.free_months_amount || 0),
                            total_payments: parseFloat((network.total_received - network.free_months_amount).toFixed(2)),
                            payment_count: network.payment_count || 0,
                            installation_revenue: 0,
                            installation_count: 0,
                            total_perceptions: 0,
                            paid_to_provider: 0,
                            profit: 0
                          };
                        });
                        
                        (installationsByNetwork || []).forEach(inst => {
                          if (!networkStatsMap[inst.network_type]) {
                            networkStatsMap[inst.network_type] = {
                              network_type: inst.network_type,
                              total_received_gross: 0,
                              free_months_amount: 0,
                              total_payments: 0,
                              payment_count: 0,
                              installation_revenue: 0,
                              installation_count: 0,
                              total_perceptions: 0,
                              paid_to_provider: 0,
                              profit: 0
                            };
                          }
                          networkStatsMap[inst.network_type].installation_revenue = parseFloat(inst.installation_revenue || 0);
                          networkStatsMap[inst.network_type].installation_count = inst.installation_count || 0;
                        });
                        
                        (paidByNetwork || []).forEach(paid => {
                          if (networkStatsMap[paid.network_type]) {
                            networkStatsMap[paid.network_type].paid_to_provider = parseFloat(paid.total_paid || 0);
                          }
                        });
                        
                        // Calcular percepciones y ganancia por red
                        const networkStats = Object.values(networkStatsMap).map(network => {
                          const totalPerceptionsNetwork = parseFloat((network.total_payments + network.installation_revenue).toFixed(2));
                          const profitNetwork = parseFloat((totalPerceptionsNetwork - network.paid_to_provider).toFixed(2));
                          return {
                            ...network,
                            total_perceptions: totalPerceptionsNetwork,
                            profit: profitNetwork
                          };
                        });
                        
                        res.json({
                          month: currentMonth,
                          total_payments: totalPayments,
                          total_payments_net: totalPaymentsNet,
                          free_months_amount: freeMonthsAmount,
                          free_months_count: paymentsSummary?.free_months_count || 0,
                          total_installations: totalInstallations,
                          total_perceptions: totalPerceptions,
                          total_expenses: totalExpenses,
                          expense_count: expensesSummary?.expense_count || 0,
                          total_paid_to_providers: totalPaidToProviders,
                          total_transfers: totalTransfers,
                          total_profit: totalProfit,
                          clients_count: clientsRow?.clients_count || 0,
                          payments_count: paymentsSummary?.payment_count || 0,
                          installations_count: installationsCountRow?.installations_count || 0,
                          folios_count: foliosRow?.folios_count || 0,
                          network_stats: networkStats
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
});

module.exports = router;
