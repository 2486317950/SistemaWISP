COPIA DE SEGURIDAD - MIGRACIÓN
===============================
Fecha: 2026-02-22 21-30-06

CONTENIDO
---------
- database.sqlite  : Base de datos completa (clientes, pagos, instalaciones, portal, etc.)
- .env             : Variables de entorno (revisar y ajustar en el nuevo servidor)

RESTAURACIÓN EN EL NUEVO SERVIDOR
---------------------------------
1. Instalar Node.js y dependencias del proyecto (npm install en /server).
2. Copiar database.sqlite a la carpeta /server del nuevo servidor
   (reemplazar el archivo si existe).
3. Copiar .env a /server y revisar/ajustar:
   - PORT, NODE_ENV
   - JWT_SECRET (recomendado generar uno nuevo y actualizar solo si es necesario)
   - Cualquier URL o credencial específica del nuevo servidor
4. Reiniciar el servicio (pm2, systemd, etc.).

NOTA: La base de datos incluye todos los datos: usuarios, clientes, pagos,
comprobantes (archivos en BLOB), chats del portal, configuración, etc.
