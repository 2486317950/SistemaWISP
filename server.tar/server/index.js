require('dotenv').config();
const { validateEnv } = require('./lib/envValidation');
validateEnv();

const express = require('express');
const http = require('http');
const cors = require('cors');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');
const db = require('./database');
const { initSocket } = require('./socket');
const { authenticateToken } = require('./middleware/auth');
const { getHelmetConfig, apiLimiter, sanitizeInput } = require('./middleware/security');
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const clientRoutes = require('./routes/clients');
const packageRoutes = require('./routes/packages');
const paymentRoutes = require('./routes/payments');
const installationRoutes = require('./routes/installations');
const folioRoutes = require('./routes/folios');
const backupRoutes = require('./routes/backup');
const providerPaymentRoutes = require('./routes/providerPayments');
const supplyInvoiceRoutes = require('./routes/supplyInvoices');
const quotationRoutes = require('./routes/quotations');
const revenueRoutes = require('./routes/revenues');
const receiptRoutes = require('./routes/receipts');
const expenseRoutes = require('./routes/expenses');
const networkRoutes = require('./routes/networks');
const growthRoutes = require('./routes/growth');
const financialProjectionsRoutes = require('./routes/financialProjections');
const contractRoutes = require('./routes/contracts');
const accountRoutes = require('./routes/accounts');
const transferRoutes = require('./routes/transfers');
const trafficRoutes = require('./routes/traffic');
const viewerRoutes = require('./routes/viewer');
const creditRoutes = require('./routes/credits');
const updateRoutes = require('./routes/update');
const fileUpdateRoutes = require('./routes/fileUpdate');
const stockRoutes = require('./routes/stock');
const antennaRoutes = require('./routes/antennas');
const cableRouteRoutes = require('./routes/cableRoutes');
const clientPortalRoutes = require('./routes/clientPortal');
const electronicInvoiceRoutes = require('./routes/electronicInvoices');
const ticketRoutes = require('./routes/tickets');
const paymentProofRoutes = require('./routes/paymentProofs');
const portalConfigRoutes = require('./routes/portalConfig');
const creditRequestsRoutes = require('./routes/creditRequests');
const creditPaymentProofRoutes = require('./routes/creditPaymentProofs');
const broadcastNotificationsRoutes = require('./routes/broadcastNotifications');
const appVersionsRoutes = require('./routes/appVersions');
const investorRoutes = require('./routes/investors');
const portalChatsRoutes = require('./routes/portalChats');
const staffPushRoutes = require('./routes/staffPush');
const auditRoutes = require('./routes/audit');

const app = express();

// Necesario cuando detrás de proxy (ngrok, nginx, etc.) para que express-rate-limit identifique correctamente la IP
app.set('trust proxy', 1);

const server = http.createServer(app);

let employeeRoutes;
try {
  employeeRoutes = require('./routes/employees');
  console.log('Ruta employees cargada correctamente');
} catch (err) {
  console.error('Error al cargar ruta employees:', err);
  employeeRoutes = express.Router();
}
let ipCredentialsRoutes;
try {
  ipCredentialsRoutes = require('./routes/ipCredentials');
  console.log('Ruta ipCredentials cargada correctamente');
} catch (err) {
  console.error('Error al cargar ruta ipCredentials:', err);
  ipCredentialsRoutes = express.Router();
}
const PORT = process.env.PORT || 5000;

// Variable para rastrear si la base de datos está lista
let dbReady = false;

// Middleware básico
// Configurar CORS para permitir acceso desde cualquier origen (red local e Internet)
app.use(cors({
  origin: '*', // Permitir acceso desde cualquier origen
  credentials: false,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Seguridad: cabeceras HTTP (Helmet)
app.use(getHelmetConfig());

// Middleware para deshabilitar caché en respuestas API cuando se solicita
app.use((req, res, next) => {
  // Si la petición tiene parámetro _t (timestamp), deshabilitar caché
  if (req.query._t) {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('Last-Modified', new Date().toUTCString());
  }
  next();
});

// Aumentar límite de tamaño para JSON (necesario para backups con imágenes)
// 100MB debería ser suficiente para backups grandes con imágenes BLOB
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

// Seguridad: sanitización de entradas (anti-inyección)
app.use(sanitizeInput);

// Seguridad: rate limiting para API (anti brute-force/DDoS)
app.use('/api', apiLimiter);

    // Middleware de logging (solo en desarrollo)
    if (process.env.NODE_ENV !== 'production') {
      app.use((req, res, next) => {
        console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
        next();
      });
    }

// Ruta de salud/verificación (sin verificación de BD)
app.get('/api/health', (req, res) => {
  res.json({ 
    status: dbReady ? 'ok' : 'initializing', 
    message: dbReady ? 'Servidor funcionando correctamente' : 'Base de datos inicializándose',
    dbReady 
  });
});

// Ruta para generar datos de tráfico de ejemplo (solo en desarrollo)
if (process.env.NODE_ENV !== 'production') {
  app.post('/api/traffic/generate-sample', (req, res) => {
    if (!dbReady) {
      return res.status(503).json({ error: 'Base de datos no está lista' });
    }
    
    const { generateSampleTraffic } = require('./scripts/generate-sample-traffic');
    generateSampleTraffic()
      .then(() => {
        res.json({ message: 'Datos de tráfico de ejemplo generados exitosamente' });
      })
      .catch((err) => {
        console.error('Error al generar datos de ejemplo:', err);
        res.status(500).json({ error: 'Error al generar datos de ejemplo: ' + err.message });
      });
  });
}

// Ruta para obtener información del servidor (útil para clientes remotos)
app.get('/api/server-info', (req, res) => {
  const getNetworkIPs = () => {
    const interfaces = os.networkInterfaces();
    const ips = [];
    
    for (const name of Object.keys(interfaces)) {
      for (const iface of interfaces[name]) {
        if (iface.family === 'IPv4' && !iface.internal) {
          ips.push({
            address: iface.address,
            interface: name
          });
        }
      }
    }
    
    return ips;
  };

  res.json({
    port: PORT,
    host: req.headers.host || `0.0.0.0:${PORT}`,
    networkIPs: getNetworkIPs(),
    mode: process.env.NODE_ENV || 'development',
    cors: true,
    multiusuario: true
  });
});

// Ruta para reiniciar el servidor (solo admin)
app.post('/api/server/restart', authenticateToken, (req, res) => {
  // Verificar que el usuario sea admin
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Solo los administradores pueden reiniciar el servidor' });
  }

  // Responder inmediatamente antes de reiniciar
  res.json({ 
    message: 'Servidor reiniciándose...',
    timestamp: new Date().toISOString()
  });

  // Ejecutar el script de reinicio completo después de un pequeño delay
  setTimeout(() => {
    try {
      const restartScript = path.join(__dirname, '..', 'scripts', 'restart-server.js');
      const fs = require('fs');
      
      if (fs.existsSync(restartScript)) {
        // Usar el script de Node.js que cierra todo y reinicia desde cero
        // Ejecutar en una nueva ventana para que se vea el proceso
        const isWindows = process.platform === 'win32';
        
        if (isWindows) {
          // En Windows, ejecutar en una nueva ventana de consola
          // Usar la ruta completa del script
          const restartScriptPath = path.resolve(restartScript);
          spawn('cmd.exe', [
            '/c', 
            'start', 
            '"Reinicio Servidor"', 
            '/D', 
            path.join(__dirname, '..'),
            'node.exe',
            restartScriptPath
          ], {
            detached: true,
            stdio: 'ignore',
            cwd: path.join(__dirname, '..'),
            shell: false
          });
        } else {
          // En Linux/Mac, ejecutar en background
          const child = spawn('node', [restartScript], {
            detached: true,
            stdio: 'inherit',
            cwd: path.join(__dirname, '..')
          });
          child.unref();
        }
      } else {
        // Si no existe el script, usar process.exit
        console.log('⚠️ Reiniciando servidor...');
        process.exit(0);
      }
    } catch (error) {
      console.error('Error al reiniciar servidor:', error);
      // Si falla, intentar con process.exit
      process.exit(0);
    }
  }, 1000);
});

// Sistema de heartbeat para detectar cuando se cierra el navegador
// Solo activo cuando NODE_ENV es 'production' (modo ngrok)
let heartbeatClients = new Map(); // Map<sessionId, lastHeartbeat>

app.post('/api/heartbeat', (req, res) => {
  const sessionId = req.body.sessionId || req.headers['x-session-id'] || 'default';
  heartbeatClients.set(sessionId, Date.now());
  res.json({ status: 'ok', timestamp: Date.now() });
});

app.get('/api/heartbeat/status', (req, res) => {
  const now = Date.now();
  const timeout = 60000; // 60 segundos de timeout
  const activeClients = Array.from(heartbeatClients.entries())
    .filter(([_, lastHeartbeat]) => now - lastHeartbeat < timeout)
    .length;
  
  res.json({ 
    activeClients,
    hasActiveClients: activeClients > 0,
    clients: Array.from(heartbeatClients.entries()).map(([id, timestamp]) => ({
      sessionId: id,
      lastHeartbeat: timestamp,
      isActive: now - timestamp < timeout
    }))
  });
});

// Limpiar clientes inactivos periódicamente
setInterval(() => {
  const now = Date.now();
  const timeout = 60000; // 60 segundos
  for (const [sessionId, lastHeartbeat] of heartbeatClients.entries()) {
    if (now - lastHeartbeat > timeout * 2) { // Eliminar después de 2 minutos de inactividad
      heartbeatClients.delete(sessionId);
    }
  }
}, 30000); // Verificar cada 30 segundos

// Middleware para verificar que la base de datos esté lista (solo para rutas API, excepto health, server-info y login)
app.use('/api', (req, res, next) => {
  // Permitir acceso a /api/health, /api/server-info, /api/auth/login y /api/client-portal/login sin verificación
  if (req.path === '/health' || req.path === '/server-info' || req.path === '/auth/login' || req.path.startsWith('/client-portal/')) {
    return next();
  }
  
  if (!dbReady) {
    return res.status(503).json({ 
      error: 'Servicio no disponible. La base de datos aún se está inicializando.' 
    });
  }
  next();
});

// Middleware para restringir acceso de técnicos solo a instalaciones y folios
// Este middleware se ejecutará después de que las rutas apliquen authenticateToken
// Se aplica de forma global pero solo afecta a técnicos después de autenticación
app.use('/api', (req, res, next) => {
  // Solo aplicar restricciones si el usuario está autenticado y es técnico
  // Nota: req.user solo está disponible después de authenticateToken en cada ruta
  // Este middleware funciona en conjunto con los middlewares específicos de cada ruta
  next();
});

// Inicializar base de datos y luego iniciar servidor
db.init()
  .then(() => {
    console.log('Base de datos inicializada correctamente');
    dbReady = true;
    
    // Inicializar Firebase (notificaciones push)
    try {
      const { init: initPush } = require('./services/pushService');
      initPush();
    } catch (error) {
      console.warn('⚠️  Firebase:', error?.message || error);
    }

    // Inicializar job de recordatorios de pago
    try {
      const paymentReminderJob = require('./jobs/paymentReminderJob');
      paymentReminderJob.start();
    } catch (error) {
      console.warn('⚠️  No se pudo iniciar job de recordatorios:', error?.message || error);
    }

    // Inicializar job de limpieza de bloques portal expirados
    try {
      const portalBlockCleanupJob = require('./jobs/portalBlockCleanupJob');
      portalBlockCleanupJob.start();
    } catch (error) {
      console.warn('⚠️  No se pudo iniciar job de limpieza de bloques portal:', error?.message || error);
    }
    // Retención de auditoría (eliminar registros antiguos)
    try {
      const auditRetentionJob = require('./jobs/auditRetentionJob');
      auditRetentionJob.start();
    } catch (error) {
      console.warn('⚠️  No se pudo iniciar job de retención de auditoría:', error?.message || error);
    }

    // Inicializar monitor de tráfico automático
    try {
      const trafficMonitor = require('./services/trafficMonitor');
      const monitorInterval = process.env.TRAFFIC_MONITOR_INTERVAL || 60; // segundos, default 60
      trafficMonitor.start(parseInt(monitorInterval));
      console.log(`📊 Monitor de tráfico automático iniciado (intervalo: ${monitorInterval}s)`);
    } catch (error) {
      console.warn('⚠️  No se pudo iniciar el monitor de tráfico:', error.message);
    }
    
    // Rutas
    app.use('/api/auth', authRoutes);
    app.use('/api/users', userRoutes);
    app.use('/api/clients', clientRoutes);
    app.use('/api/packages', packageRoutes);
    app.use('/api/payments', paymentRoutes);
    app.use('/api/installations', installationRoutes);
    app.use('/api/folios', folioRoutes);
    app.use('/api/backup', backupRoutes);
    app.use('/api/provider-payments', providerPaymentRoutes);
    app.use('/api/supply-invoices', supplyInvoiceRoutes);
    app.use('/api/quotations', quotationRoutes);
    app.use('/api/revenues', revenueRoutes);
    app.use('/api/investors', investorRoutes);
    app.use('/api/receipts', receiptRoutes);
    app.use('/api/expenses', expenseRoutes);
    app.use('/api/networks', networkRoutes);
app.use('/api/growth', growthRoutes);
app.use('/api/financial-projections', financialProjectionsRoutes);
app.use('/api/contracts', contractRoutes);
    app.use('/api/accounts', accountRoutes);
    app.use('/api/transfers', transferRoutes);
    app.use('/api/traffic', trafficRoutes);
    app.use('/api/viewer', viewerRoutes);
    app.use('/api/credits', creditRoutes);
    app.use('/api/server', updateRoutes);
    app.use('/api/server', fileUpdateRoutes);
    app.use('/api/stock', stockRoutes);
    app.use('/api/antennas', antennaRoutes);
    app.use('/api/cable-routes', cableRouteRoutes);
    app.use('/api/client-portal', clientPortalRoutes);
    app.use('/api/portal-chats', portalChatsRoutes);
    app.use('/api/staff', staffPushRoutes);
    const chatProvider = process.env.GEMINI_API_KEY ? 'Gemini (gratis)' : (process.env.OPENAI_API_KEY ? 'OpenAI' : 'ninguno');
    console.log(`💬 Chat IA: ${chatProvider}`);
    app.use('/api/electronic-invoices', electronicInvoiceRoutes);
    app.use('/api/tickets', ticketRoutes);
    app.use('/api/payment-proofs', paymentProofRoutes);
    app.use('/api/portal-config', portalConfigRoutes);
    app.use('/api/credit-requests', creditRequestsRoutes);
    app.use('/api/credit-payment-proofs', creditPaymentProofRoutes);
    app.use('/api/broadcast-notifications', broadcastNotificationsRoutes);
    app.use('/api/app-versions', appVersionsRoutes);
    app.use('/api/audit', auditRoutes);
    if (employeeRoutes) {
      app.use('/api/employees', employeeRoutes);
      console.log('Ruta /api/employees registrada');
    } else {
      console.error('ERROR: No se pudo registrar la ruta /api/employees');
    }
    if (ipCredentialsRoutes) {
      app.use('/api/ip-credentials', ipCredentialsRoutes);
      console.log('Ruta /api/ip-credentials registrada');
    } else {
      console.error('ERROR: No se pudo registrar la ruta /api/ip-credentials');
    }

    console.log('Rutas registradas:');
    console.log('- /api/auth');
    console.log('- /api/users');
    console.log('- /api/clients');
    console.log('- /api/packages');
    console.log('- /api/payments');
    console.log('- /api/installations');
    console.log('- /api/folios');
    console.log('- /api/backup');
    console.log('- /api/provider-payments');
    console.log('- /api/supply-invoices');
    console.log('- /api/quotations');
    console.log('- /api/revenues');
    console.log('- /api/receipts');
    console.log('- /api/networks');
    console.log('- /api/growth');
    console.log('- /api/contracts');
    console.log('- /api/accounts');
    console.log('- /api/transfers');
    console.log('- /api/traffic');
    console.log('- /api/viewer');
    console.log('- /api/credits');
    console.log('- /api/server (update, restart)');
    console.log('- /api/employees');
    console.log('- /api/ip-credentials');

    // Servir archivos estáticos del frontend en producción (debe ir después de las rutas API)
    const fs = require('fs');
    const clientPath = path.join(__dirname, '../client/dist');
    
    // Detectar modo: producción si NODE_ENV es 'production' O si la carpeta dist existe (para compatibilidad)
    const isProduction = process.env.NODE_ENV === 'production' || fs.existsSync(clientPath);
    
    console.log(`🔍 Verificando modo y carpeta dist...`);
    console.log(`   NODE_ENV: ${process.env.NODE_ENV || 'no definido'}`);
    console.log(`   Ruta client/dist: ${clientPath}`);
    console.log(`   Existe client/dist: ${fs.existsSync(clientPath)}`);
    console.log(`   Modo detectado: ${isProduction ? 'PRODUCCIÓN' : 'DESARROLLO'}`);
    
    if (isProduction) {
      // Verificar que la carpeta dist existe
      if (fs.existsSync(clientPath)) {
        console.log(`✅ Modo producción: Serviendo frontend desde client/dist`);
        // Servir archivos estáticos
        app.use(express.static(clientPath));
        
        // Todas las rutas que no sean /api/* deben servir el index.html del frontend
        // Esto permite que React Router maneje las rutas del frontend
        app.get('*', (req, res) => {
          // Si la ruta comienza con /api, devolver 404
          if (req.path.startsWith('/api')) {
            return res.status(404).json({ error: 'Ruta no encontrada' });
          }
          // De lo contrario, servir el index.html del frontend
          res.sendFile(path.join(clientPath, 'index.html'), (err) => {
            if (err) {
              console.error('Error al servir archivo estático:', err);
              res.status(404).json({ error: 'Archivo no encontrado' });
            }
          });
        });
      } else {
        console.warn('⚠️  AVISO: La carpeta client/dist no existe. El frontend no se servirá.');
        console.warn('   Ejecuta "npm run build" para construir el frontend.');
        // Manejar rutas no encontradas
        app.use((req, res) => {
          if (req.path.startsWith('/api')) {
            res.status(404).json({ error: 'Ruta no encontrada' });
          } else {
            res.status(404).json({ error: 'Frontend no construido. Ejecuta "npm run build"' });
          }
        });
      }
    } else {
      console.log(`⚠️  Modo desarrollo: Frontend se sirve en puerto 3000`);
      // En desarrollo, solo manejar rutas API
      app.use((req, res) => {
        if (req.path.startsWith('/api')) {
          res.status(404).json({ error: 'Ruta no encontrada' });
        } else {
          res.status(404).json({ error: 'Ruta no encontrada. En desarrollo, el frontend se sirve en puerto 3000' });
        }
      });
    }

    // Middleware de manejo de errores global (debe ir al final)
    app.use((err, req, res, next) => {
      console.error('Error no manejado:', err);
      console.error('Stack:', err.stack);
      res.status(500).json({ 
        error: 'Error interno del servidor',
        message: process.env.NODE_ENV === 'development' ? err.message : 'Ha ocurrido un error inesperado'
      });
    });

    // Función para obtener las IPs de red disponibles
    const getNetworkIPs = () => {
      const interfaces = os.networkInterfaces();
      const ips = [];
      
      for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
          // Omitir direcciones IPv6 y no internas (es decir, solo IPv4)
          if (iface.family === 'IPv4' && !iface.internal) {
            ips.push({
              address: iface.address,
              interface: name
            });
          }
        }
      }
      
      return ips;
    };

    // Inicializar Socket.IO
    initSocket(server);

    server.listen(PORT, '0.0.0.0', () => {
      const isProdMode = process.env.NODE_ENV === 'production' || fs.existsSync(path.join(__dirname, '../client/dist'));
      const publicUrl = process.env.PUBLIC_URL || process.env.NGROK_URL || 'https://sistemacdcom.ngrok.dev';
      const networkIPs = getNetworkIPs();

      console.log(`\n${'='.repeat(60)}`);
      console.log(`✅ Servidor corriendo en puerto ${PORT}`);
      console.log(`${'='.repeat(60)}`);
      console.log(`📦 Modo: ${isProdMode ? 'Producción' : 'Desarrollo'}`);
      if (isProdMode) {
        console.log(`📁 Frontend: ${path.join(__dirname, '../client/dist')}`);
      }
      console.log(`\n${'─'.repeat(60)}`);
      console.log(`🌐 URLs ACTIVAS`);
      console.log(`${'─'.repeat(60)}`);
      console.log(`\n  Local:`);
      console.log(`    • http://localhost:${PORT}`);
      console.log(`    • http://127.0.0.1:${PORT}`);
      if (networkIPs.length > 0) {
        console.log(`\n  Red local:`);
        networkIPs.forEach(({ address, interface: iface }) => {
          console.log(`    • http://${address}:${PORT}  (${iface})`);
        });
      }
      console.log(`\n  Internet (ngrok):`);
      console.log(`    • ${publicUrl}`);
      console.log(`    • ${publicUrl}/portal   (portal clientes)`);
      console.log(`    • ${publicUrl}/investor/login (app inversionista)`);
      console.log(`\n${'─'.repeat(60)}`);
      console.log(`✅ Servidor listo | CORS activo | Socket.IO activo\n`);

      // Verificar si ngrok está corriendo (asíncrono)
      setTimeout(() => {
        try {
          const { checkNgrok } = require('../scripts/check-ngrok');
          checkNgrok().then((ngrokUrl) => {
            if (ngrokUrl && ngrokUrl !== publicUrl) {
              console.log(`🚀 Ngrok detectado: ${ngrokUrl}\n`);
            }
          }).catch(() => {});
        } catch (e) {}
      }, 2000);
    });

    // Manejar errores al iniciar el servidor (puerto en uso)
    server.on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        console.error(`\n❌ ERROR: El puerto ${PORT} ya está en uso.`);
        console.error(`   Por favor, detén el servidor anterior o usa otro puerto.`);
        console.error(`   Ejecuta: npm run stop:servers`);
        console.error(`   O ejecuta: bat-scripts\\DETENER_SERVIDORES.bat\n`);
        process.exit(1);
      } else {
        console.error(`\n❌ ERROR al iniciar el servidor:`, err);
        process.exit(1);
      }
    });

    // Exportar server para usar en otros módulos si es necesario
    module.exports.server = server;
  })
  .catch((err) => {
    console.error('Error al inicializar la base de datos:', err);
    console.error('Stack:', err.stack);
    console.error('El servidor no se iniciará debido a un error en la base de datos.');
    process.exit(1);
  });

// Manejo de errores no capturados
process.on('uncaughtException', (err) => {
  console.error('Excepción no capturada:', err);
  console.error('Stack:', err.stack);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Promesa rechazada no manejada:', reason);
  console.error('Promise:', promise);
});

