import React, { useState, useEffect } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import './Layout.css';

const Layout = () => {
  const { logout, user } = useAuth();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const { isAdmin, isTechnician } = useAuth();

  // Registrar token FCM en la app del personal (Android) para notificaciones push
  useEffect(() => {
    if (!user) return;
    const isStaffApp = typeof window !== 'undefined' && window.Android?.isApp?.();
    if (!isStaffApp) return;
    const registerFCM = () => {
      const token = window.Android?.getFCMToken?.();
      if (token && token.length > 50) {
        api.post('/staff/register-fcm', { token }).catch(() => {});
      }
    };
    registerFCM();
    const retry = setInterval(registerFCM, 3000);
    return () => clearInterval(retry);
  }, [user]);
  
  // Menú para técnicos: solo instalaciones, folios y desbloquear portal
  const technicianMenuSections = [
    { title: 'Operaciones', items: [
      { path: '/installations', label: 'Instalaciones', icon: '🔧' },
      { path: '/folios', label: 'Folios', icon: '📋' },
      { path: '/portal-unlock', label: 'Desbloquear Portal', icon: '🔓' }
    ]}
  ];
  
  // Menú completo organizado en secciones
  const fullMenuSections = [
    { title: 'Principal', items: [
      { path: '/', label: 'Dashboard', icon: '📊' }
    ]},
    { title: 'Clientes', items: [
      { path: '/clients', label: 'Clientes', icon: '👥' },
      { path: '/client-contract', label: 'Contrato Cliente', icon: '📄' },
      { path: '/contracts', label: 'Contratos Guardados', icon: '📋' },
      { path: '/packages', label: 'Paquetes', icon: '📦' }
    ]},
    { title: 'Finanzas', items: [
      { path: '/investors', label: 'Inversionistas', icon: '📈' },
      { path: '/payments', label: 'Pagos', icon: '💰' },
      { path: '/credits', label: 'Créditos', icon: '💳' },
      { path: '/provider-payments', label: 'Pago Proveedores', icon: '💳' },
      { path: '/supply-invoices', label: 'Facturas de Insumos', icon: '🧾' },
      { path: '/receipts', label: 'Recibos', icon: '🧾' },
      { path: '/payment-proofs', label: 'Comprobantes Clientes', icon: '📤' },
      { path: '/credit-payment-proofs', label: 'Comprobantes Crédito', icon: '💳' },
      { path: '/credit-requests', label: 'Solicitudes de Crédito', icon: '💳' },
      { path: '/expenses', label: 'Gastos', icon: '📉' },
      { path: '/transfers', label: 'Transferencias', icon: '💸' }
    ]},
    { title: 'Operaciones', items: [
      { path: '/quotations', label: 'Cotizaciones', icon: '📝' },
      { path: '/installations', label: 'Instalaciones', icon: '🔧' },
      { path: '/folios', label: 'Folios', icon: '📋' },
      { path: '/tickets', label: 'Tickets', icon: '🎫' }
    ]},
    { title: 'Inventario', items: [
      { path: '/stock', label: 'Stock/Insumos', icon: '📦' }
    ]},
    { title: 'Recursos Humanos', items: [
      { path: '/employees', label: 'Empleados', icon: '👔' }
    ]},
    { title: 'Red', items: [
      { path: '/ip-credentials', label: 'IPs y Contraseñas', icon: '🔐' },
      { path: '/networks', label: 'Redes', icon: '📡' },
      { path: '/map', label: 'Mapa', icon: '🗺️' },
      { path: '/traffic', label: 'Tráfico', icon: '📊' }
    ]},
    { title: 'Reportes', items: [
      { path: '/monthly-reports', label: 'Reportes Mensuales', icon: '📊' },
      { path: '/growth', label: 'Crecimiento Mensual', icon: '📈' },
      { path: '/financial-projections', label: 'Proyecciones Financieras', icon: '📉' }
    ]},
    { title: 'Facturación', items: [
      { path: '/electronic-invoices', label: 'Facturación Electrónica', icon: '📑' }
    ]},
    { title: 'Comunicación', items: [
      { path: '/whatsapp', label: 'WhatsApp', icon: '💬' },
      { path: '/portal-chats', label: 'Chats del Portal', icon: '💬' },
      { path: '/client-notifications', label: 'Notificaciones Clientes', icon: '🔔' },
      { path: '/portal-unlock', label: 'Desbloquear Portal', icon: '🔓' }
    ]},
    { title: 'Sistema', items: [
      { path: '/settings', label: 'Configuración', icon: '⚙️' },
      ...(isAdmin ? [{ path: '/users', label: 'Usuarios', icon: '👤' }] : []),
      ...(isAdmin ? [] : [])
    ]}
  ];
  
  const menuSections = isTechnician ? technicianMenuSections : fullMenuSections;

  return (
    <div className="layout">
      {mobileMenuOpen && (
        <div 
          className="mobile-overlay"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}
      <aside className={`sidebar ${sidebarOpen ? 'open' : 'closed'} ${mobileMenuOpen ? 'mobile-open' : ''}`}>
        <div className="sidebar-header">
          <h2>🌐 Sistema ISP</h2>
          <button className="toggle-btn" onClick={() => {
            setSidebarOpen(!sidebarOpen);
            if (window.innerWidth <= 768) {
              setMobileMenuOpen(false);
            }
          }}>
            {sidebarOpen ? '◀' : '▶'}
          </button>
        </div>
        <nav className="sidebar-nav">
          {menuSections.map((section) => (
            <div key={section.title} className="nav-section">
              {sidebarOpen && <div className="nav-section-title">{section.title}</div>}
              {section.items.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`nav-item ${location.pathname === item.path || (item.path === '/growth' && location.pathname.startsWith('/growth')) ? 'active' : ''}`}
                  onClick={() => {
                    if (window.innerWidth <= 768) {
                      setMobileMenuOpen(false);
                    }
                  }}
                >
                  <span className="nav-icon">{item.icon}</span>
                  {sidebarOpen && <span className="nav-label">{item.label}</span>}
                </Link>
              ))}
            </div>
          ))}
        </nav>
      </aside>
      <main className="main-content">
        <header className="top-header">
          <button 
            className="mobile-menu-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            ☰
          </button>
          <div className="header-content">
            <h1 className="page-title">CDCom Comunicaciones</h1>
            <div className="header-user-info">
              {user && (
                <div className="user-info">
                  <span className="user-label">Usuario:</span>
                  <span className="user-name">{user.username}</span>
                  {user.role && (
                    <span className="user-role">({user.role})</span>
                  )}
                </div>
              )}
              <button onClick={logout} className="logout-btn-fixed" title="Cerrar Sesión">
                <span>🚪</span>
                <span>Cerrar Sesión</span>
              </button>
            </div>
          </div>
        </header>
        <div className="content-wrapper">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default Layout;

