import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSocket } from '../context/SocketContext';
import api from '../services/api';
import './Dashboard.css';

const Dashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    clients: 0,
    packages: 0,
    payments: 0,
    installations: 0,
    folios: 0,
    totalRevenue: 0,
    freeMonths: 0,
    installationRevenue: 0,
    totalReceivedWithoutInstallations: 0,
    totalReceivedWithInstallations: 0,
    netRevenueWithoutInstallations: 0,
    netRevenueWithInstallations: 0,
    totalPaidToProviders: 0,
    totalExpenses: 0,
    expenseCount: 0,
    networkStats: [],
    totalNetworkProfit: 0
  });
  const [loading, setLoading] = useState(true);
  const [statsError, setStatsError] = useState(null);
  const [growthData, setGrowthData] = useState([]);
  const [loadingGrowth, setLoadingGrowth] = useState(true);
  const [expandedNetworks, setExpandedNetworks] = useState(new Set());
  const [currentMonthStats, setCurrentMonthStats] = useState(null);
  const [daysUntilCutoff, setDaysUntilCutoff] = useState(0);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [stockStats, setStockStats] = useState({
    total_items: 0,
    total_quantity: 0,
    low_stock_count: 0,
    out_of_stock_count: 0
  });
  const [activeCredits, setActiveCredits] = useState([]);
  const { subscribe } = useSocket();

  useEffect(() => {
    fetchStats();
    fetchGrowthData();
    fetchCurrentMonthStats();
    fetchStockStats();
    fetchActiveCredits();
    
    // Timeout de seguridad: si después de 15 segundos todavía está cargando, forzar el render
    const timeout = setTimeout(() => {
      console.warn('Timeout: Forzando render del dashboard después de 15 segundos');
      setLoading(false);
    }, 15000);
    
    return () => clearTimeout(timeout);
  }, []);

  // Calcular días hasta el corte del mes
  useEffect(() => {
    const calculateDaysUntilCutoff = () => {
      const now = new Date();
      const currentYear = now.getFullYear();
      const currentMonth = now.getMonth();
      
      // El corte del mes es el último día del mes actual (día antes de que los contadores vuelvan a 0)
      // El último día del mes es el día 0 del siguiente mes
      const cutoffDate = new Date(currentYear, currentMonth + 1, 0);
      
      // Establecer ambas fechas al inicio del día para comparar solo días completos
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const cutoffDay = new Date(cutoffDate.getFullYear(), cutoffDate.getMonth(), cutoffDate.getDate());
      
      // Calcular la diferencia en milisegundos
      const diffTime = cutoffDay - today;
      
      // Convertir a días completos (usando Math.floor para obtener días completos restantes)
      // Si estamos en el mismo día, la diferencia será 0
      const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
      
      setDaysUntilCutoff(Math.max(0, diffDays));
    };

    // Calcular inmediatamente
    calculateDaysUntilCutoff();

    // Actualizar cada minuto
    const interval = setInterval(calculateDaysUntilCutoff, 60000);

    return () => clearInterval(interval);
  }, []);

  // Actualizar fecha actual cada minuto
  useEffect(() => {
    const updateDate = () => {
      setCurrentDate(new Date());
    };

    // Actualizar inmediatamente
    updateDate();

    // Actualizar cada minuto
    const interval = setInterval(updateDate, 60000);

    return () => clearInterval(interval);
  }, []);

  // Suscribirse a actualizaciones en tiempo real de gastos, pagos, proveedores, etc.
  useEffect(() => {
    const unsubscribeExpenses = subscribe('expenses', (event, data) => {
      console.log('Evento de gasto recibido:', event, data);
      fetchStats();
      fetchCurrentMonthStats();
    });

    const unsubscribePayments = subscribe('payments', (event, data) => {
      console.log('Evento de pago recibido:', event, data);
      fetchStats();
      fetchCurrentMonthStats();
    });

    const unsubscribeProviderPayments = subscribe('provider_payments', (event, data) => {
      console.log('Evento de pago a proveedor recibido:', event, data);
      fetchStats();
      fetchCurrentMonthStats();
    });

    const unsubscribeCredits = subscribe('credits', () => {
      fetchActiveCredits();
    });

    return () => {
      unsubscribeExpenses();
      unsubscribePayments();
      unsubscribeProviderPayments();
      if (typeof unsubscribeCredits === 'function') unsubscribeCredits();
    };
  }, [subscribe]);

  const fetchGrowthData = async () => {
    try {
      setLoadingGrowth(true);
      const response = await api.get('/growth/monthly');
      setGrowthData(response.data || []);
    } catch (error) {
      console.error('Error al cargar datos de crecimiento:', error);
      // Si falla, establecer un array vacío para que la app no se bloquee
      setGrowthData([]);
    } finally {
      setLoadingGrowth(false);
    }
  };

  const fetchCurrentMonthStats = async () => {
    try {
      const response = await api.get('/revenues/summary/current-month');
      setCurrentMonthStats(response.data || null);
    } catch (error) {
      console.error('Error al cargar estadísticas del mes actual:', error);
      setCurrentMonthStats(null);
    }
  };

  const formatMonth = (monthStr) => {
    if (!monthStr) return '';
    const [year, month] = monthStr.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1, 1);
    return date.toLocaleDateString('es-ES', { month: 'short', year: 'numeric' });
  };

  const handleChartClick = (data, index) => {
    if (data && data.activePayload && data.activePayload.length > 0) {
      const month = data.activePayload[0].payload.month;
      if (month) {
        navigate(`/growth/month/${month}`);
      }
    } else if (data && data.month) {
      // Si el data viene directamente con el mes (desde Bar onClick)
      navigate(`/growth/month/${data.month}`);
    } else if (data && data.payload && data.payload.month) {
      // Si el data viene desde Line dot onClick
      navigate(`/growth/month/${data.payload.month}`);
    }
  };

  const getGrowthColor = (growthPercent, isPercent = false) => {
    if (isPercent) {
      return parseFloat(growthPercent) >= 0 ? '#27ae60' : '#e74c3c';
    }
    return growthPercent >= 0 ? '#27ae60' : '#e74c3c';
  };

  const toggleNetwork = (networkType) => {
    setExpandedNetworks(prev => {
      const newSet = new Set(prev);
      if (newSet.has(networkType)) {
        newSet.delete(networkType);
      } else {
        newSet.add(networkType);
      }
      return newSet;
    });
  };


  const fetchStats = async () => {
    setStatsError(null);
    try {
      // Usar Promise.allSettled para que si una petición falla, las otras continúen
      const results = await Promise.allSettled([
        api.get('/clients').catch(e => ({ data: [] })),
        api.get('/packages').catch(e => ({ data: [] })),
        api.get('/payments').catch(e => ({ data: [] })),
        api.get('/installations').catch(e => ({ data: [] })),
        api.get('/folios').catch(e => ({ data: [] })),
        api.get('/revenues/summary').catch(e => ({ data: {} }))
      ]);

      // Extraer datos de cada resultado
      const clientsData = results[0].status === 'fulfilled' ? (results[0].value?.data || []) : [];
      const packagesData = results[1].status === 'fulfilled' ? (results[1].value?.data || []) : [];
      const paymentsData = results[2].status === 'fulfilled' ? (results[2].value?.data || []) : [];
      const installationsData = results[3].status === 'fulfilled' ? (results[3].value?.data || []) : [];
      const foliosData = results[4].status === 'fulfilled' ? (results[4].value?.data || []) : [];
      const summary = results[5].status === 'fulfilled' ? (results[5].value?.data || {}) : {};

      // NUEVA LÓGICA FINANCIERA:
      // 1. Total de Percepciones = Total de Pagos + Instalaciones
      // 2. Ganancia = Total de Percepciones - Gastos - Pagos a Proveedores
      
      // Calcular estadísticas (asegurar que todos sean números con parseFloat)
      const totalPayments = parseFloat(summary.total_payments || 0);
      const freeMonths = summary.free_months_count || 0;
      const installationRevenue = parseFloat(summary.total_installations || 0);
      const totalPerceptions = parseFloat(summary.total_perceptions || summary.total_revenue || 0); // Nueva lógica
      const totalPaymentsNet = parseFloat(summary.total_payments_net || summary.total_received_without_installations || 0);
      const totalPaidToProviders = parseFloat(summary.total_paid_to_providers || 0);
      const totalExpenses = parseFloat(summary.total_expenses || 0);
      const expenseCount = summary.expense_count || 0;
      const totalTransfers = parseFloat(summary.total_transfers || 0);
      const totalProfit = parseFloat(summary.total_profit || summary.net_revenue_with_installations || 0); // Nueva ganancia
      const networkStats = Array.isArray(summary.network_stats) ? summary.network_stats : [];
      
      // Calcular la suma de percepciones de ambas redes
      const totalNetworkPerceptions = parseFloat(networkStats.reduce((sum, network) => {
        return sum + (parseFloat(network.total_perceptions || 0) || 0);
      }, 0).toFixed(2));

      setStats({
        clients: Array.isArray(clientsData) ? clientsData.length : 0,
        packages: Array.isArray(packagesData) ? packagesData.length : 0,
        payments: Array.isArray(paymentsData) ? paymentsData.length : 0,
        installations: Array.isArray(installationsData) ? installationsData.length : 0,
        folios: Array.isArray(foliosData) ? foliosData.length : 0,
        // Nueva lógica financiera
        totalPayments,
        freeMonths,
        installationRevenue,
        totalPerceptions,
        totalPaymentsNet,
        totalPaidToProviders,
        totalExpenses,
        expenseCount,
        totalTransfers,
        totalProfit,
        networkStats,
        totalNetworkPerceptions,
        // Mantener compatibilidad
        totalRevenue: totalPerceptions,
        totalReceivedWithoutInstallations: totalPaymentsNet,
        totalReceivedWithInstallations: totalPerceptions,
        netRevenueWithoutInstallations: totalProfit,
        netRevenueWithInstallations: totalProfit,
        totalNetworkProfit: totalNetworkPerceptions
      });
    } catch (error) {
      console.error('Error crítico al cargar estadísticas:', error);
      setStatsError(error.response?.data?.error || 'Error al cargar las estadísticas');
    } finally {
      // Siempre desactivar el estado de carga
      setLoading(false);
    }
  };

  const fetchStockStats = async () => {
    try {
      const response = await api.get('/stock/stats/summary');
      setStockStats(response.data);
    } catch (error) {
      console.error('Error al cargar estadísticas de stock:', error);
    }
  };

  const fetchActiveCredits = async () => {
    try {
      const response = await api.get('/credits');
      const activos = (response.data || []).filter(c => c.status !== 'liquidado');
      setActiveCredits(activos);
    } catch (error) {
      console.error('Error al cargar créditos activos:', error);
      setActiveCredits([]);
    }
  };

  return (
    <div className="dashboard" style={{ padding: '20px', minHeight: '100vh' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px', flexWrap: 'wrap', gap: '20px' }}>
        <div>
          <h1 style={{ color: '#2c3e50', margin: 0 }}>Dashboard</h1>
          {currentMonthStats && (
            <p style={{ color: '#7f8c8d', margin: '5px 0 0 0', fontSize: '0.9rem' }}>
              Datos del mes: {new Date().toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}
            </p>
          )}
        </div>
        <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
          <div className="current-date-card">
            <div className="current-date-icon">📅</div>
            <div className="current-date-content">
              <div className="current-date-label">Fecha Actual</div>
              <div className="current-date-day">
                {currentDate.toLocaleDateString('es-ES', { day: 'numeric' })}
              </div>
              <div className="current-date-subtitle">
                {currentDate.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}
              </div>
              <div className="current-date-time">
                {currentDate.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
          <div className="cutoff-countdown">
            <div className="cutoff-countdown-icon">⏰</div>
            <div className="cutoff-countdown-content">
              <div className="cutoff-countdown-label">Días hasta el corte</div>
              <div className={`cutoff-countdown-days ${daysUntilCutoff <= 3 ? 'urgent' : daysUntilCutoff <= 7 ? 'warning' : ''}`}>
                {daysUntilCutoff}
              </div>
              <div className="cutoff-countdown-subtitle">
                {daysUntilCutoff === 0 
                  ? 'Corte hoy' 
                  : daysUntilCutoff === 1 
                  ? 'Corte mañana' 
                  : `Corte: ${new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toLocaleDateString('es-ES', { day: 'numeric', month: 'long' })}`}
              </div>
            </div>
          </div>
        </div>
      </div>
      {statsError && (
        <div className="error-message-banner" style={{ marginBottom: '1rem' }}>
          {statsError}
          <button type="button" onClick={() => { setStatsError(null); fetchStats(); }}>Reintentar</button>
        </div>
      )}
      {loading ? (
        <div className="dashboard-loading">Cargando estadísticas...</div>
      ) : (
        <>
          <div className="stats-grid">
        <div className="stat-card" onClick={() => navigate('/clients')}>
          <div className="stat-icon">👥</div>
          <div className="stat-info">
            <h3>Clientes</h3>
            <p className="stat-number">{currentMonthStats ? currentMonthStats.clients_count : 0}</p>
            <small style={{ fontSize: '0.8rem', color: '#7f8c8d' }}>Este mes</small>
          </div>
        </div>
        <div className="stat-card" onClick={() => navigate('/packages')}>
          <div className="stat-icon">📦</div>
          <div className="stat-info">
            <h3>Paquetes</h3>
            <p className="stat-number">{stats.packages}</p>
          </div>
        </div>
        <div className="stat-card" onClick={() => navigate('/payments')}>
          <div className="stat-icon">💰</div>
          <div className="stat-info">
            <h3>Pagos</h3>
            <p className="stat-number">{currentMonthStats ? currentMonthStats.payments_count : 0}</p>
            <small style={{ fontSize: '0.8rem', color: '#7f8c8d' }}>Este mes</small>
          </div>
        </div>
        <div className="stat-card" onClick={() => navigate('/installations')}>
          <div className="stat-icon">🔧</div>
          <div className="stat-info">
            <h3>Instalaciones</h3>
            <p className="stat-number">{currentMonthStats ? currentMonthStats.installations_count : 0}</p>
            <small style={{ fontSize: '0.8rem', color: '#7f8c8d' }}>Este mes</small>
          </div>
        </div>
        <div className="stat-card" onClick={() => navigate('/folios')}>
          <div className="stat-icon">📋</div>
          <div className="stat-info">
            <h3>Folios</h3>
            <p className="stat-number">{currentMonthStats ? currentMonthStats.folios_count : 0}</p>
            <small style={{ fontSize: '0.8rem', color: '#7f8c8d' }}>Este mes</small>
          </div>
        </div>
        <div className="stat-card" onClick={() => navigate('/credits')} style={{
          borderLeft: activeCredits.length > 0 ? '4px solid #f39c12' : '4px solid #95a5a6'
        }}>
          <div className="stat-icon">💳</div>
          <div className="stat-info">
            <h3>Créditos activos</h3>
            <p className="stat-number">{activeCredits.length}</p>
            <small style={{ fontSize: '0.8rem', color: '#7f8c8d' }}>
              {activeCredits.length > 0 ? `${activeCredits.reduce((s, c) => s + parseFloat(c.remaining_amount || 0), 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })} pendiente` : 'Sin créditos pendientes'}
            </small>
          </div>
        </div>
        <div className="stat-card" onClick={() => navigate('/stock')} style={{ 
          borderLeft: stockStats.out_of_stock_count > 0 ? '4px solid #e74c3c' : 
                      stockStats.low_stock_count > 0 ? '4px solid #f39c12' : 
                      '4px solid #27ae60' 
        }}>
          <div className="stat-icon">📦</div>
          <div className="stat-info">
            <h3>Stock/Insumos</h3>
            <p className="stat-number">{stockStats.total_items}</p>
            <small style={{ 
              fontSize: '0.8rem', 
              color: stockStats.out_of_stock_count > 0 ? '#e74c3c' : 
                     stockStats.low_stock_count > 0 ? '#f39c12' : 
                     '#7f8c8d' 
            }}>
              {stockStats.out_of_stock_count > 0 && `⚠️ ${stockStats.out_of_stock_count} sin stock`}
              {stockStats.out_of_stock_count === 0 && stockStats.low_stock_count > 0 && `⚠️ ${stockStats.low_stock_count} con stock bajo`}
              {stockStats.out_of_stock_count === 0 && stockStats.low_stock_count === 0 && 'Todo en orden'}
            </small>
          </div>
        </div>
      </div>
      
      <div className="revenue-section">
        <h2>💰 Ingresos y Finanzas</h2>
        <div className="revenue-grid">
          <div className="revenue-card" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white' }}>
            <div className="revenue-icon" style={{ fontSize: '2.5rem' }}>📊</div>
            <div className="revenue-info">
              <h3 style={{ color: 'white' }}>Total de Percepciones</h3>
              <p className="revenue-amount" style={{ color: 'white', fontSize: '1.8rem' }}>
                ${currentMonthStats ? parseFloat(currentMonthStats.total_perceptions || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}
              </p>
              <p className="revenue-subtitle" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>
                Este mes: Pagos + Instalaciones
              </p>
            </div>
          </div>
          <div className="revenue-card">
            <div className="revenue-icon">💵</div>
            <div className="revenue-info">
              <h3>Total de Pagos</h3>
              <p className="revenue-amount">${currentMonthStats ? parseFloat(currentMonthStats.total_payments_net || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}</p>
              <p className="revenue-subtitle">Este mes: Pagos netos (sin meses gratis)</p>
            </div>
          </div>
          <div className="revenue-card">
            <div className="revenue-icon">🔧</div>
            <div className="revenue-info">
              <h3>Total Instalaciones</h3>
              <p className="revenue-amount">${currentMonthStats ? parseFloat(currentMonthStats.total_installations || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}</p>
              <p className="revenue-subtitle">Este mes: Ingresos por instalaciones</p>
            </div>
          </div>
          <div className="revenue-card">
            <div className="revenue-icon">💳</div>
            <div className="revenue-info">
              <h3>Pagado a Proveedores</h3>
              <p className="revenue-amount">${currentMonthStats ? parseFloat(currentMonthStats.total_paid_to_providers || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}</p>
              <p className="revenue-subtitle">Este mes: Total pagado a proveedores</p>
            </div>
          </div>
          <div className="revenue-card" onClick={() => navigate('/expenses')} style={{ cursor: 'pointer' }}>
            <div className="revenue-icon">📉</div>
            <div className="revenue-info">
              <h3>Total Gastos</h3>
              <p className="revenue-amount" style={{ color: '#e74c3c' }}>${currentMonthStats ? parseFloat(currentMonthStats.total_expenses || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}</p>
              <p className="revenue-subtitle">Este mes: {currentMonthStats ? (currentMonthStats.expense_count || 0) : 0} {currentMonthStats && currentMonthStats.expense_count === 1 ? 'gasto registrado' : 'gastos registrados'}</p>
            </div>
          </div>
          <div className="revenue-card net-revenue" style={{ background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', color: 'white', gridColumn: '1 / -1' }}>
            <div className="revenue-icon" style={{ fontSize: '3rem' }}>💎</div>
            <div className="revenue-info">
              <h3 style={{ color: 'white', fontSize: '1.5rem' }}>Ganancia Total</h3>
              <p className="revenue-amount net" style={{ color: 'white', fontSize: '2.5rem', fontWeight: 'bold' }}>
                ${currentMonthStats ? parseFloat(currentMonthStats.total_profit || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}
              </p>
              <p className="revenue-subtitle" style={{ color: 'rgba(255, 255, 255, 0.9)', fontSize: '1rem', marginTop: '15px' }}>
                Este mes: Percepciones ({currentMonthStats ? parseFloat(currentMonthStats.total_perceptions || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}) - 
                Gastos ({currentMonthStats ? parseFloat(currentMonthStats.total_expenses || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}, incluye pagos a proveedores) - 
                Transferencias ({currentMonthStats ? parseFloat(currentMonthStats.total_transfers || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'})
              </p>
            </div>
          </div>
          {currentMonthStats && currentMonthStats.network_stats && currentMonthStats.network_stats.length > 0 && (
            <div className="revenue-card network-stats-card" style={{ gridColumn: '1 / -1' }}>
              <div className="revenue-info" style={{ width: '100%' }}>
                <h3 style={{ marginBottom: '15px' }}>📊 Desglose Detallado por Red (Este Mes)</h3>
                <div className="network-stats-grid">
                  {currentMonthStats.network_stats.map((network, index) => {
                    const totalBruto = network.total_received_gross || 0;
                    const mesesGratis = network.free_months_amount || 0;
                    const totalPagos = network.total_payments || network.total_received_without_installations || 0;
                    const instalaciones = network.installation_revenue || 0;
                    const totalPercepciones = network.total_perceptions || (totalPagos + instalaciones);
                    const pagadoProveedor = network.paid_to_provider || 0;
                    const ganancia = network.profit || (totalPercepciones - pagadoProveedor);
                    const isExpanded = expandedNetworks.has(network.network_type);
                    
                    return (
                      <div key={index} className={`network-stat-item ${isExpanded ? 'expanded' : 'collapsed'}`}>
                        <div 
                          className="network-stat-header" 
                          onClick={() => toggleNetwork(network.network_type)}
                          style={{ cursor: 'pointer' }}
                        >
                          <h4>{network.network_type}</h4>
                          <div className="network-stat-header-summary">
                            <span className="network-summary-item">
                              <strong>Percepciones:</strong> 
                              ${totalPercepciones.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </span>
                            <span className="network-summary-item">
                              <strong>Ganancia (sin gastos):</strong> 
                              <span className={ganancia >= 0 ? 'profit-positive' : 'profit-negative'}>
                                ${ganancia.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                              </span>
                            </span>
                          </div>
                          <span className="network-toggle-icon">{isExpanded ? '▼' : '▶'}</span>
                        </div>
                        <div className={`network-stat-details ${isExpanded ? 'expanded' : 'collapsed'}`}>
                          {/* Sección: Ingresos */}
                          <div className="network-stat-section">
                            <div className="network-stat-section-title">💰 Ingresos</div>
                            <div className="network-stat-row">
                              <span>Total Bruto de Pagos:</span>
                              <strong>${totalBruto.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                            </div>
                            <div className="network-stat-row highlight-negative">
                              <span>Meses Gratis:</span>
                              <strong>${mesesGratis.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                            </div>
                            <div className="network-stat-row highlight-positive">
                              <span>Total de Pagos (Neto):</span>
                              <strong>${totalPagos.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                            </div>
                            {instalaciones > 0 && (
                              <div className="network-stat-row highlight-positive">
                                <span>Ingresos por Instalaciones:</span>
                                <strong>${instalaciones.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                              </div>
                            )}
                            <div className="network-stat-row" style={{ background: 'rgba(102, 126, 234, 0.15)', borderTop: '2px solid #667eea', fontWeight: 'bold' }}>
                              <span>Total de Percepciones:</span>
                              <strong style={{ fontSize: '1.1rem' }}>${totalPercepciones.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                            </div>
                          </div>

                          {/* Sección: Egresos */}
                          <div className="network-stat-section">
                            <div className="network-stat-section-title">💳 Egresos</div>
                            <div className="network-stat-row highlight-negative">
                              <span>Pagado a Proveedor:</span>
                              <strong>${pagadoProveedor.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                            </div>
                          </div>


                          {/* Sección: Resumen */}
                          <div className="network-stat-section">
                            <div className="network-stat-section-title">📈 Resumen</div>
                            <div className="network-stat-row">
                              <span>Cantidad de Pagos:</span>
                              <strong>{network.payment_count || 0}</strong>
                            </div>
                            {network.installation_count > 0 && (
                              <div className="network-stat-row">
                                <span>Cantidad de Instalaciones:</span>
                                <strong>{network.installation_count || 0}</strong>
                              </div>
                            )}
                            <div className="network-stat-row profit" style={{ background: 'rgba(39, 174, 96, 0.15)', borderTop: '2px solid #27ae60' }}>
                              <span>Ganancia de la Red (sin gastos):</span>
                              <strong className={ganancia >= 0 ? 'profit-positive' : 'profit-negative'} style={{ fontSize: '1.15rem' }}>
                                ${ganancia.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                              </strong>
                            </div>
                            {totalPercepciones > 0 && (
                              <div className="network-stat-row">
                                <span>Margen de Ganancia:</span>
                                <strong className={ganancia >= 0 ? 'profit-positive' : 'profit-negative'}>
                                  {((ganancia / totalPercepciones) * 100).toFixed(1)}%
                                </strong>
                              </div>
                            )}
                            <div className="network-stat-row" style={{ marginTop: '10px', paddingTop: '10px', borderTop: '1px solid #ddd', fontStyle: 'italic', color: '#7f8c8d' }}>
                              <span>Nota: Los gastos son universales y se aplican al total general, no por red individual.</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {activeCredits.length > 0 && (
        <div className="credits-activos-section" style={{ marginTop: '30px' }}>
          <h2 style={{ marginBottom: '15px', color: '#2c3e50' }}>💳 Créditos activos</h2>
          <div style={{ background: 'white', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: '#f8f9fa' }}>
                  <th style={{ padding: '12px', textAlign: 'left', fontWeight: 600 }}>Cliente</th>
                  <th style={{ padding: '12px', textAlign: 'left', fontWeight: 600 }}>Tipo</th>
                  <th style={{ padding: '12px', textAlign: 'right', fontWeight: 600 }}>Pendiente</th>
                  <th style={{ padding: '12px', textAlign: 'center', fontWeight: 600 }}>Estado</th>
                  <th style={{ padding: '12px', textAlign: 'right', fontWeight: 600 }}>Acción</th>
                </tr>
              </thead>
              <tbody>
                {activeCredits.slice(0, 10).map((c) => (
                  <tr key={c.id} style={{ borderBottom: '1px solid #eee' }}>
                    <td style={{ padding: '12px' }}>
                      <strong>{c.display_name || c.client_name || 'Sin cliente'}</strong>
                      {c.client_number && <div style={{ fontSize: '0.85em', color: '#6c757d' }}>#{c.client_number}</div>}
                    </td>
                    <td style={{ padding: '12px' }}>{c.credit_type === 'instalacion' ? 'Instalación' : 'Mensualidad'}</td>
                    <td style={{ padding: '12px', textAlign: 'right', color: '#e74c3c', fontWeight: 600 }}>
                      ${parseFloat(c.remaining_amount || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                    </td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>
                      <span style={{
                        padding: '4px 10px',
                        borderRadius: '12px',
                        fontSize: '0.85em',
                        fontWeight: 600,
                        background: c.status === 'pendiente' ? '#fff3cd' : '#cfe2ff',
                        color: c.status === 'pendiente' ? '#856404' : '#084298'
                      }}>
                        {c.status === 'pendiente' ? 'Pendiente' : 'Parcial'}
                      </span>
                    </td>
                    <td style={{ padding: '12px', textAlign: 'right' }}>
                      <button
                        onClick={(e) => { e.stopPropagation(); navigate('/credits'); }}
                        style={{
                          background: '#007bff',
                          color: 'white',
                          border: 'none',
                          padding: '6px 14px',
                          borderRadius: '4px',
                          cursor: 'pointer',
                          fontSize: '0.9em'
                        }}
                      >
                        Ver / Pagar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {activeCredits.length > 10 && (
              <div style={{ padding: '12px', textAlign: 'center', background: '#f8f9fa' }}>
                <button
                  onClick={() => navigate('/credits')}
                  style={{ background: 'none', border: 'none', color: '#007bff', cursor: 'pointer', fontSize: '14px' }}
                >
                  Ver todos los {activeCredits.length} créditos activos →
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {!loadingGrowth && growthData.length > 0 && (
        <div className="growth-section">
          <h2>📈 Crecimiento Mensual</h2>
          
          {/* Resumen del último mes */}
          {growthData.length > 0 && (() => {
            const lastMonth = growthData[growthData.length - 1];
            const previousMonthData = growthData.length > 1 ? growthData[growthData.length - 2] : null;
            
            return (
              <div className="last-month-summary">
                <h3>Resumen del Último Mes ({formatMonth(lastMonth.month)})</h3>
                <div className="summary-cards">
                  <div className="summary-card" onClick={() => handleChartClick({ activePayload: [{ payload: lastMonth }] })} style={{ cursor: 'pointer' }}>
                    <div className="summary-icon">💰</div>
                    <div className="summary-content">
                      <div className="summary-label">Ingresos</div>
                      <div className="summary-value">${lastMonth.totalRevenue.toLocaleString('es-MX', { minimumFractionDigits: 2 })}</div>
                      {previousMonthData && (
                        <div className="summary-growth" style={{ color: getGrowthColor(lastMonth.revenueGrowthPercent, true) }}>
                          {lastMonth.revenueGrowth >= 0 ? '↑' : '↓'} {Math.abs(parseFloat(lastMonth.revenueGrowthPercent))}%
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="summary-card" onClick={() => handleChartClick({ activePayload: [{ payload: lastMonth }] })} style={{ cursor: 'pointer' }}>
                    <div className="summary-icon">👥</div>
                    <div className="summary-content">
                      <div className="summary-label">Clientes</div>
                      <div className="summary-value">{lastMonth.clients}</div>
                      {previousMonthData && (
                        <div className="summary-growth" style={{ color: getGrowthColor(lastMonth.clientsGrowthPercent, true) }}>
                          {lastMonth.clientsGrowth >= 0 ? '↑' : '↓'} {Math.abs(parseFloat(lastMonth.clientsGrowthPercent))}%
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="summary-card" onClick={() => handleChartClick({ activePayload: [{ payload: lastMonth }] })} style={{ cursor: 'pointer' }}>
                    <div className="summary-icon">🔧</div>
                    <div className="summary-content">
                      <div className="summary-label">Instalaciones</div>
                      <div className="summary-value">{lastMonth.installations}</div>
                      {previousMonthData && (
                        <div className="summary-growth" style={{ color: getGrowthColor(lastMonth.installationsGrowthPercent, true) }}>
                          {lastMonth.installationsGrowth >= 0 ? '↑' : '↓'} {Math.abs(parseFloat(lastMonth.installationsGrowthPercent))}%
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="summary-card" onClick={() => handleChartClick({ activePayload: [{ payload: lastMonth }] })} style={{ cursor: 'pointer' }}>
                    <div className="summary-icon">📋</div>
                    <div className="summary-content">
                      <div className="summary-label">Folios</div>
                      <div className="summary-value">{lastMonth.folios}</div>
                      {previousMonthData && (
                        <div className="summary-growth" style={{ color: getGrowthColor(lastMonth.foliosGrowthPercent, true) }}>
                          {lastMonth.foliosGrowth >= 0 ? '↑' : '↓'} {Math.abs(parseFloat(lastMonth.foliosGrowthPercent))}%
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <p style={{ marginTop: '20px', textAlign: 'center', color: '#7f8c8d' }}>
                  Haz clic en las tarjetas para ver detalles del mes
                </p>
              </div>
            );
          })()}
          </div>
        )}
        </>
      )}
    </div>
  );
};

export default Dashboard;


