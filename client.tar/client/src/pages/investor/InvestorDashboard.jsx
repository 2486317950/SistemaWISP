import React, { useState, useEffect, useCallback } from 'react';
import api from '../../services/api';
import { useSocket } from '../../context/SocketContext';
import './InvestorDashboard.css';

const getDefaultMonth = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
};

const InvestorDashboard = () => {
  const [month, setMonth] = useState(getDefaultMonth);
  const [loading, setLoading] = useState(true);
  const [totalIngresos, setTotalIngresos] = useState(0);
  const [totalGastos, setTotalGastos] = useState(0);
  const [gananciaNeta, setGananciaNeta] = useState(0);
  const [myPercentage, setMyPercentage] = useState(0);
  const [myGanancia, setMyGanancia] = useState(0);
  const [totalInstalaciones, setTotalInstalaciones] = useState(0);
  const { subscribe } = useSocket();

  const fetchData = useCallback(async (showLoading = true) => {
    if (showLoading) setLoading(true);
    try {
      const [summaryRes, meRes] = await Promise.allSettled([
        api.get(`/revenues/summary/for-month?month=${month}`),
        api.get('/investors/me').catch(() => ({ data: null }))
      ]);

      const summary = summaryRes.status === 'fulfilled' ? summaryRes.value?.data || {} : {};
      const me = meRes.status === 'fulfilled' && meRes.value?.data ? meRes.value.data : null;

      const ingresos = parseFloat(summary.total_perceptions || 0);
      const gastos = parseFloat(summary.total_expenses || 0);
      const neta = parseFloat(summary.total_profit || 0);
      const pct = me ? parseFloat(me.percentage || 0) : 0;
      const miGanancia = parseFloat((neta * (pct / 100)).toFixed(2));
      const instalaciones = parseFloat(summary.total_installations || 0);

      setTotalIngresos(ingresos);
      setTotalGastos(gastos);
      setGananciaNeta(neta);
      setMyPercentage(pct);
      setMyGanancia(miGanancia);
      setTotalInstalaciones(instalaciones);
    } catch (err) {
      console.error('Error al cargar datos:', err);
    } finally {
      setLoading(false);
    }
  }, [month]);

  useEffect(() => {
    fetchData(true);
  }, [fetchData]);

  useEffect(() => {
    const unsubPayments = subscribe('payments', () => fetchData(false));
    const unsubExpenses = subscribe('expenses', () => fetchData(false));
    return () => {
      unsubPayments();
      unsubExpenses();
    };
  }, [subscribe, fetchData]);

  const formatCurrency = (n) =>
    new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n || 0);

  if (loading) {
    return <div className="investor-loading">Cargando datos...</div>;
  }

  const monthLabel = month
    ? new Date(month + '-01').toLocaleDateString('es-MX', { month: 'long', year: 'numeric' })
    : '';

  return (
    <div className="investor-dashboard">
      <div className="investor-dashboard-header">
        <h2 className="investor-page-title">Resumen financiero</h2>
        <div className="investor-dashboard-month">
          <label>Mes:</label>
          <input
            type="month"
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            className="investor-month-input"
          />
          <span className="investor-month-label">{monthLabel}</span>
        </div>
      </div>

      <div className="investor-dashboard-cards">
        <div className="investor-dashboard-card">
          <span className="investor-dashboard-card-label">Total ingresos</span>
          <span className="investor-dashboard-card-value income">{formatCurrency(totalIngresos)}</span>
        </div>
        <div className="investor-dashboard-card">
          <span className="investor-dashboard-card-label">Total gastos</span>
          <span className="investor-dashboard-card-value expenses">{formatCurrency(totalGastos)}</span>
        </div>
        <div className="investor-dashboard-card">
          <span className="investor-dashboard-card-label">Ganancia neta</span>
          <span className="investor-dashboard-card-value net">{formatCurrency(gananciaNeta)}</span>
        </div>
        <div className="investor-dashboard-card highlight">
          <span className="investor-dashboard-card-label">Tu ganancia ({myPercentage}%)</span>
          <span className="investor-dashboard-card-value my">{formatCurrency(myGanancia)}</span>
        </div>
      </div>

      <div className="investor-dashboard-info-card">
        <span className="investor-dashboard-info-icon">📋</span>
        <div className="investor-dashboard-info-content">
          <div className="investor-dashboard-info-header">
            <strong>Instalaciones</strong>
            <span className="investor-dashboard-info-amount">{formatCurrency(totalInstalaciones)}</span>
          </div>
          <p>Los ingresos por instalaciones no generan utilidad para el inversionista. Solo la ganancia neta por mensualidades y otros conceptos acordados aplica a tu porcentaje.</p>
        </div>
      </div>
    </div>
  );
};

export default InvestorDashboard;
