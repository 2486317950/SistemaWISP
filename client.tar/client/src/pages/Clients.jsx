import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import api from '../services/api';
import ClientForm from '../components/ClientForm';
import './Clients.css';

const Clients = () => {
  const { canUpdate, canDelete } = useAuth();
  const [clients, setClients] = useState([]);
  const [packages, setPackages] = useState([]);
  const [networks, setNetworks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [deletingId, setDeletingId] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedNetwork, setSelectedNetwork] = useState(null);

  const { subscribe } = useSocket();

  useEffect(() => {
    fetchClients();
    fetchPackages();
    fetchNetworks();
  }, []);

  // Suscribirse a actualizaciones en tiempo real
  useEffect(() => {
    const unsubscribe = subscribe('clients', (event, data) => {
      console.log('Evento de cliente recibido:', event, data);
      // Recargar clientes cuando hay cambios
      fetchClients();
    });

    return unsubscribe;
  }, [subscribe]);

  const fetchNetworks = async () => {
    try {
      const response = await api.get('/networks?active_only=true');
      setNetworks(response.data);
    } catch (error) {
      console.error('Error al cargar redes:', error);
    }
  };

  const fetchClients = async () => {
    setLoadError(null);
    try {
      const response = await api.get('/clients');
      setClients(response.data);
    } catch (error) {
      console.error('Error al cargar clientes:', error);
      setLoadError(error.response?.data?.error || 'Error al cargar la lista de clientes');
    } finally {
      setLoading(false);
    }
  };

  const fetchPackages = async () => {
    try {
      const response = await api.get('/packages?active_only=true');
      setPackages(response.data);
    } catch (error) {
      console.error('Error al cargar paquetes:', error);
    }
  };

  const handleDelete = async (id) => {
    if (deletingId) return;
    setDeletingId(id);
    try {
      const response = await api.delete(`/clients/${id}`);
      setLoadError(null);
      setClients((prev) => prev.filter((c) => c.id !== id));
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Error al eliminar el cliente';
      setLoadError(errorMessage);
    } finally {
      setDeletingId(null);
    }
  };

  const handleFormSubmit = () => {
    setShowForm(false);
    setEditingClient(null);
    fetchClients();
  };

  const filteredClients = clients.filter(client => {
    // Filtro por búsqueda de texto
    const matchesSearch = client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.address.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filtro por red
    const matchesNetwork = selectedNetwork === null || client.network_type === selectedNetwork;
    
    return matchesSearch && matchesNetwork;
  });

  if (loading && clients.length === 0) {
    return <div className="loading">Cargando clientes...</div>;
  }

  return (
    <div className="clients-page">
      <div className="page-header">
        <h1>Clientes</h1>
        <button className="btn-primary" onClick={() => setShowForm(true)}>
          + Agregar Cliente
        </button>
      </div>

      {loadError && (
        <div className="error-message-banner">
          {loadError}
          <button type="button" className="btn-dismiss-error" onClick={() => setLoadError(null)} aria-label="Cerrar">×</button>
        </div>
      )}

      {showForm && (
        <ClientForm
          client={editingClient}
          packages={packages}
          onClose={() => {
            setShowForm(false);
            setEditingClient(null);
          }}
          onSuccess={handleFormSubmit}
        />
      )}

      <div className="filters-section">
        <div className="search-bar">
          <input
            type="text"
            placeholder="Buscar por nombre o domicilio..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="network-filters">
          <button
            className={`network-filter-btn ${selectedNetwork === null ? 'active' : ''}`}
            onClick={() => setSelectedNetwork(null)}
          >
            📡 Todas las Redes
          </button>
          {networks.map((network) => (
            <button
              key={network.id}
              className={`network-filter-btn ${selectedNetwork === network.name ? 'active' : ''}`}
              onClick={() => setSelectedNetwork(network.name)}
            >
              {network.name}
            </button>
          ))}
        </div>
      </div>

      <div className="clients-grid">
        {filteredClients.map((client) => (
          <div key={client.id} className="client-card">
            <div className="client-header">
              <div className="client-title-section">
                <h3>{client.name}</h3>
                {(client.client_number || client.network_type) && (
                  <div className="client-badges">
                    {client.client_number && (
                      <span className="client-number-badge">#{client.client_number}</span>
                    )}
                    {client.network_type && (
                      <span className="network-type-badge">{client.network_type}</span>
                    )}
                  </div>
                )}
              </div>
              <div className="client-actions">
                {canUpdate && (
                  <button
                    className="btn-icon"
                    onClick={() => {
                      setEditingClient(client);
                      setShowForm(true);
                    }}
                    title="Editar"
                  >
                    ✏️
                  </button>
                )}
                {canDelete && (
                  <button
                    className="btn-icon"
                    onClick={() => handleDelete(client.id)}
                    title="Eliminar"
                    disabled={deletingId === client.id}
                  >
                    {deletingId === client.id ? '⏳' : '🗑️'}
                  </button>
                )}
              </div>
            </div>
            <div className="client-info">
              {client.client_number && (
                <p><strong>🔢 Número de Cliente:</strong> {client.client_number}</p>
              )}
              <p><strong>📍 Domicilio:</strong> {client.address}</p>
              {client.phone && (
                <p>
                  <strong>📞 Teléfono:</strong> {client.phone}
                  <a
                    href={`https://wa.me/${client.phone.replace(/\D/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="whatsapp-link"
                    title="Abrir WhatsApp"
                  >
                    💬 WhatsApp
                  </a>
                </p>
              )}
              {client.email && <p><strong>📧 Email:</strong> {client.email}</p>}
              {client.network_type && (
                <p><strong>📡 Tipo de Red:</strong> {client.network_type}</p>
              )}
              {client.package_name && (
                <p><strong>📦 Paquete:</strong> {client.package_name} ({client.speed})</p>
              )}
              {(client.app_version_name || client.app_version_code) && (
                <p><strong>📱 App:</strong> v{client.app_version_name || client.app_version_code}</p>
              )}
              {client.notes && (
                <p><strong>📝 Notas:</strong> {client.notes}</p>
              )}
            </div>
            <Link to={`/clients/${client.id}`} className="btn-view">
              Ver Detalles →
            </Link>
          </div>
        ))}
      </div>

      {filteredClients.length === 0 && (
        <div className="empty-state">
          <p>No se encontraron clientes</p>
        </div>
      )}
    </div>
  );
};

export default Clients;

