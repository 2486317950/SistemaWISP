import React, { useState, useEffect } from 'react';

/**
 * Wrapper para el Mapa - solo renderiza en el cliente.
 * Evita errores de Leaflet con SSR o hidratación.
 */
const MapWrapper = () => {
  const [MapComponent, setMapComponent] = useState(null);

  useEffect(() => {
    import('./Map').then((mod) => setMapComponent(() => mod.default));
  }, []);

  if (!MapComponent) {
    return (
      <div className="loading" style={{ padding: '40px', textAlign: 'center' }}>
        Cargando mapa...
      </div>
    );
  }

  return <MapComponent />;
};

export default MapWrapper;
