import React, { useState, useEffect } from 'react';
import portalApi from '../../services/portalApi';
import './PortalPaymentProofs.css';

const PortalPaymentProofs = () => {
  const [proofs, setProofs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [file, setFile] = useState(null);
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');

  const loadProofs = () => {
    portalApi.get('/client-portal/payment-proofs')
      .then((res) => setProofs(res.data || []))
      .catch(() => setProofs([]))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadProofs();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!file) {
      alert('Selecciona un archivo (captura de transferencia o comprobante de depósito)');
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    if (amount) formData.append('amount', amount);
    if (notes) formData.append('notes', notes);

    portalApi.post('/client-portal/payment-proofs', formData)
      .then(() => {
        setFile(null);
        setAmount('');
        setNotes('');
        loadProofs();
        alert('Comprobante subido correctamente. Será revisado por el personal.');
      })
      .catch((err) => alert(err.response?.data?.error || 'Error al subir'))
      .finally(() => setUploading(false));
  };

  const statusLabel = (s) => {
    const map = { pendiente: 'Pendiente', aprobado: 'Aprobado', rechazado: 'Rechazado' };
    return map[s] || s;
  };

  const formatDate = (d) => {
    if (!d) return '-';
    const s = String(d);
    return s.includes('T') ? s.split('T')[0].split('-').reverse().join('/') : s;
  };

  if (loading) {
    return <div className="portal-loading">Cargando...</div>;
  }

  return (
    <div className="portal-payment-proofs">
      <h2>Comprobantes de pago</h2>
      <p className="portal-proof-desc">
        Sube capturas de transferencia o comprobantes de depósito para que validemos tu pago.
      </p>

      <form onSubmit={handleSubmit} className="portal-proof-form">
        <div className="portal-form-group">
          <label>Archivo * (imagen o PDF)</label>
          <input
            type="file"
            accept="image/*,.pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            required
          />
        </div>
        <div className="portal-form-group">
          <label>Monto (opcional)</label>
          <input
            type="number"
            step="0.01"
            placeholder="Ej: 350.00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>
        <div className="portal-form-group">
          <label>Notas (opcional)</label>
          <input
            type="text"
            placeholder="Ej: Pago de mensualidad marzo"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>
        <button type="submit" className="portal-upload-btn" disabled={uploading || !file}>
          {uploading ? 'Subiendo...' : '📤 Subir comprobante'}
        </button>
      </form>

      <h3>Mis comprobantes</h3>
      {proofs.length === 0 ? (
        <div className="portal-empty">No has subido comprobantes aún</div>
      ) : (
        <div className="portal-proof-list">
          {proofs.map((p) => (
            <div key={p.id} className={`portal-proof-item status-${p.status}`}>
              <div className="proof-info">
                <span className="proof-name">{p.file_name}</span>
                <span className="proof-date">{formatDate(p.created_at)}</span>
                {p.amount && <span className="proof-amount">${parseFloat(p.amount).toFixed(2)}</span>}
                <span className={`proof-status status-${p.status}`}>{statusLabel(p.status)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PortalPaymentProofs;
