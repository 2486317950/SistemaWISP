import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import portalApi from '../../services/portalApi';
import './PortalDashboard.css';

const PortalDashboard = () => {
  const [balance, setBalance] = useState(null);
  const [serviceInfo, setServiceInfo] = useState(null);
  const [announcements, setAnnouncements] = useState([]);
  const [settings, setSettings] = useState({});
  const [lastReceipt, setLastReceipt] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([
      portalApi.get('/client-portal/balance'),
      portalApi.get('/client-portal/service-info').catch(() => null),
      portalApi.get('/client-portal/announcements').catch(() => []),
      portalApi.get('/client-portal/settings').catch(() => ({})),
      portalApi.get('/client-portal/last-receipt').catch(() => null)
    ]).then(([balRes, svcRes, annRes, setRes, lastRes]) => {
      setBalance(balRes.data);
      setServiceInfo(svcRes?.data || null);
      setAnnouncements(Array.isArray(annRes?.data) ? annRes.data : []);
      setSettings(setRes?.data || {});
      setLastReceipt(lastRes?.data || null);
    }).catch((err) => setError(err.response?.data?.error || 'Error al cargar'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="portal-loading">Cargando...</div>;
  }

  if (error) {
    return <div className="portal-error-box">{error}</div>;
  }

  const formatDate = (d) => {
    if (!d) return '-';
    const s = String(d);
    return s.includes('T') ? s.split('T')[0].split('-').reverse().join('/') : s.split('-').reverse().join('/');
  };

  const serviceStatusLabel = (s) => ({ activo: 'Activo', suspendido: 'Suspendido', baja: 'Baja' }[s] || s || 'Activo');

  const now = new Date();
  const day = now.getDate();
  const monthName = now.toLocaleDateString('es', { month: 'long' });
  const paymentReminder = day <= 6
    ? `📅 Período de pago actual: 1 al 6 de ${monthName}. ${6 - day} día(s) restante(s).`
    : day < 28
      ? `📅 Próximo período de pago: 1 al 6 de ${now.toLocaleDateString('es', { month: 'long', year: 'numeric' }).split(' ').slice(1).join(' ')}.`
      : `📅 Próximo período de pago: 1 al 6 del próximo mes.`;

  const paymentMethods = Array.isArray(settings.payment_methods) && settings.payment_methods.length > 0
    ? settings.payment_methods
    : [
        { name: 'Depósito / OXXO', detail: 'Tarjeta: 4217 4701 7385 4544' },
        { name: 'Transferencia bancaria', detail: 'CLABE: 728969000131749378' }
      ].map((m) => `${m.name} | ${m.detail}`);

  const parsePaymentMethod = (str) => {
    if (!str || typeof str !== 'string') return { name: str, detail: '' };
    const idx = str.indexOf('|');
    if (idx >= 0) return { name: str.slice(0, idx).trim(), detail: str.slice(idx + 1).trim() };
    return { name: str, detail: '' };
  };

  const hasContact = settings.contact_phone || settings.contact_whatsapp;
  const serviceStatus = settings.service_status || 'normal';
  const showServiceBanner = serviceStatus !== 'normal' && settings.service_status_message;

  return (
    <div className="portal-dashboard">
      <h2>Resumen de tu cuenta</h2>

      {showServiceBanner && (
        <div className={`portal-service-status-banner status-${serviceStatus}`}>
          <strong>{serviceStatus === 'mantenimiento' ? '🔧 Mantenimiento' : '⚠️ Aviso'}</strong>
          <p>{settings.service_status_message}</p>
        </div>
      )}

      {serviceInfo && (
        <div className="portal-service-card">
          <h3>📡 Tu servicio</h3>
          <div className="service-info-grid">
            <div><span className="label">Estado:</span> <span className={`status-badge status-${serviceInfo.service_status || 'activo'}`}>{serviceStatusLabel(serviceInfo.service_status)}</span></div>
            <div><span className="label">Paquete:</span> {serviceInfo.package_name || '-'} {serviceInfo.speed ? `(${serviceInfo.speed})` : ''}</div>
            <div><span className="label">Próximo período de pago:</span> 1 al 6 de cada mes</div>
          </div>
          <div className="portal-payment-reminder">
            {paymentReminder}
          </div>
        </div>
      )}

      {announcements.length > 0 && (
        <div className="portal-announcements">
          <h3>📢 Avisos</h3>
          {announcements.map((a) => (
            <div key={a.id} className={`announcement-item type-${a.type || 'info'}`}>
              <strong>{a.title}</strong>
              {a.content && <p>{a.content}</p>}
            </div>
          ))}
        </div>
      )}

      <div className="portal-balance-card">
        <h3 className="portal-charges-title">Cargos del mes (mensualidad)</h3>
        <div className="portal-charges-breakdown">
          <div className="portal-charge-row">
            <span>Cuota mensual</span>
            <span>${parseFloat(balance?.monthly_fee || 0).toFixed(2)}</span>
          </div>
          <div className="portal-charge-row">
            <span>Crédito aplicado</span>
            <span className="credit-amount">−${parseFloat(balance?.credit_amount || 0).toFixed(2)}</span>
          </div>
          {balance?.balance_credit > 0 && (
            <div className="portal-charge-row">
              <span>Saldo a favor</span>
              <span className="credit-amount">−${parseFloat(balance.balance_credit).toFixed(2)}</span>
            </div>
          )}
          {(balance?.current_month_paid_total || 0) > 0 && (
            <div className="portal-charge-row portal-charge-row-payment">
              <span>Pagos realizados (mensualidad)</span>
              <span className="payment-amount">−${parseFloat(balance.current_month_paid_total).toFixed(2)}</span>
            </div>
          )}
          <div className="portal-charge-row portal-charge-row-total">
            <span>Total adeudado mensualidad</span>
            <span className="portal-amount">
              ${parseFloat(balance?.amount_still_owed ?? balance?.amount_to_pay ?? 0).toFixed(2)}
            </span>
          </div>
        </div>
        {(balance?.credit_debt_paid_this_month || 0) > 0 && (
          <div className="portal-credit-debt-section">
            <h4 className="portal-section-subtitle">Pagos a deuda de crédito (parcelas)</h4>
            <div className="portal-charge-row">
              <span>Parcelas pagadas este mes</span>
              <span className="payment-amount">−${parseFloat(balance.credit_debt_paid_this_month).toFixed(2)}</span>
            </div>
            <Link to="/portal/credits" className="portal-link-parcelas">Ver parcelas en Mis créditos →</Link>
          </div>
        )}
        <div className={`portal-status ${balance?.current_month_paid ? 'paid' : 'pending'}`}>
          {balance?.current_month_paid ? (
            <>✓ Este mes está pagado</>
          ) : (
            <>⚠ Pendiente de pago. Sube tu comprobante para que sea revisado. Fechas de pago: 1 al 6 de cada mes.</>
          )}
        </div>
        {balance?.last_payment && (
          <div className="portal-last-payment">
            Último pago: ${parseFloat(balance.last_payment.amount).toFixed(2)} - {balance.last_payment.date}
          </div>
        )}
        {lastReceipt && (
          <div className="portal-last-receipt-link">
            <Link to={`/portal/receipts`} className="portal-btn-receipt">
              🧾 Ver último recibo ({lastReceipt.receipt_number})
            </Link>
          </div>
        )}
      </div>

      {hasContact && (
        <div className="portal-contact-quick">
          <h3>📞 Contactar soporte</h3>
          <div className="portal-contact-buttons">
            {settings.contact_whatsapp && (
              <a
                href={`https://wa.me/${String(settings.contact_whatsapp).replace(/\D/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="portal-contact-btn whatsapp"
              >
                💬 WhatsApp
              </a>
            )}
            {settings.contact_phone && (
              <a
                href={`tel:${String(settings.contact_phone).replace(/\s/g, '')}`}
                className="portal-contact-btn call"
              >
                📞 Llamar
              </a>
            )}
          </div>
        </div>
      )}

      <div className="portal-payment-methods">
        <h3>Métodos de pago</h3>
        {paymentMethods.map((m, i) => {
          const { name, detail } = parsePaymentMethod(m);
          return (
            <div key={i} className="payment-method-item">
              <span className="method-icon">💳</span>
              <span><strong>{name || 'Método de pago'}</strong></span>
              {detail && <span className="method-detail">{detail}</span>}
            </div>
          );
        })}
        <p className="payment-warning">
          ⚠️ Para evitar suspensión del servicio, realiza tu pago del 1 al 6 de cada mes.
        </p>
      </div>
    </div>
  );
};

export default PortalDashboard;
