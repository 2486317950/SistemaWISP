import React, { useState, useEffect, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import api from '../services/api';
import './Map.css';

// Fix para los iconos de Leaflet en producción
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Icono personalizado para antenas
const antennaIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,' + btoa(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32" height="32">
      <circle cx="12" cy="12" r="11" fill="#e74c3c" stroke="white" stroke-width="2"/>
      <text x="12" y="17" text-anchor="middle" fill="white" font-size="14" font-weight="bold">📡</text>
    </svg>
  `),
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32]
});

// Icono personalizado para clientes
const clientIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,' + btoa(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="28" height="28">
      <circle cx="12" cy="12" r="11" fill="#3498db" stroke="white" stroke-width="2"/>
      <text x="12" y="17" text-anchor="middle" fill="white" font-size="14" font-weight="bold">👤</text>
    </svg>
  `),
  iconSize: [28, 28],
  iconAnchor: [14, 28],
  popupAnchor: [0, -28]
});

// Componente para ajustar el centro del mapa
function ChangeView({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
}

// Componente para dibujar sector de cobertura
function CoverageWedge({ antenna, color }) {
  const map = useMap();
  
  useEffect(() => {
    if (!antenna.latitude || !antenna.longitude) return;
    
    const center = [parseFloat(antenna.latitude), parseFloat(antenna.longitude)];
    const range = parseFloat(antenna.range) * 1000; // Convertir km a metros
    const azimuth = parseFloat(antenna.azimuth);
    const aperture = parseFloat(antenna.aperture);
    
    // Calcular los puntos del sector
    const startAngle = azimuth - aperture / 2;
    const endAngle = azimuth + aperture / 2;
    
    const points = [center];
    const numPoints = Math.max(20, Math.ceil(aperture / 5));
    
    for (let i = 0; i <= numPoints; i++) {
      const angle = startAngle + (endAngle - startAngle) * (i / numPoints);
      const rad = (angle * Math.PI) / 180;
      
      const lat = center[0] + (range / 111320) * Math.cos(rad);
      const lng = center[1] + (range / (111320 * Math.cos(center[0] * Math.PI / 180))) * Math.sin(rad);
      
      points.push([lat, lng]);
    }
    
    points.push(center);
    
    const polygon = L.polygon(points, {
      color: color,
      fillColor: color,
      fillOpacity: 0.2,
      weight: 2
    }).addTo(map);
    
    return () => {
      map.removeLayer(polygon);
    };
  }, [antenna, color, map]);
  
  return null;
}

const Map = () => {
  const [clients, setClients] = useState([]);
  const [antennas, setAntennas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAntennaForm, setShowAntennaForm] = useState(false);
  const [editingAntenna, setEditingAntenna] = useState(null);
  const [selectedClient, setSelectedClient] = useState(null);
  const [selectedAntenna, setSelectedAntenna] = useState(null);
  const [mapCenter, setMapCenter] = useState([19.4326, -99.1332]); // Ciudad de México por defecto
  const [mapZoom, setMapZoom] = useState(13);
  const [showClients, setShowClients] = useState(true);
  const [showAntennas, setShowAntennas] = useState(true);
  const [showCoverage, setShowCoverage] = useState(true);
  const [showCableRoutes, setShowCableRoutes] = useState(true);
  const [cableRoutes, setCableRoutes] = useState([]);
  const [filterNetwork, setFilterNetwork] = useState('all');
  const [networks, setNetworks] = useState([]);
  const [drawingRoute, setDrawingRoute] = useState(false);
  const [currentRoutePoints, setCurrentRoutePoints] = useState([]);
  const [showRouteForm, setShowRouteForm] = useState(false);

  useEffect(() => {
    fetchClients();
    fetchAntennas();
    fetchNetworks();
    fetchCableRoutes();
  }, []);

  const fetchClients = async () => {
    try {
      const response = await api.get('/clients');
      setClients(response.data);
    } catch (error) {
      console.error('Error al cargar clientes:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAntennas = async () => {
    try {
      const response = await api.get('/antennas');
      setAntennas(response.data);
    } catch (error) {
      console.error('Error al cargar antenas:', error);
    }
  };

  const fetchNetworks = async () => {
    try {
      const response = await api.get('/networks?active_only=true');
      setNetworks(response.data);
    } catch (error) {
      console.error('Error al cargar redes:', error);
    }
  };

  const fetchCableRoutes = async () => {
    try {
      const response = await api.get('/cable-routes');
      setCableRoutes(response.data);
    } catch (error) {
      console.error('Error al cargar rutas de cable:', error);
    }
  };

  const handleAddAntenna = () => {
    setEditingAntenna(null);
    setShowAntennaForm(true);
  };

  const handleEditAntenna = (antenna) => {
    setEditingAntenna(antenna);
    setShowAntennaForm(true);
  };

  const handleDeleteAntenna = async (id) => {

    try {
      await api.delete(`/antennas/${id}`);
      fetchAntennas();
    } catch (error) {
      alert('Error al eliminar la antena');
    }
  };

  const handleFormSuccess = () => {
    setShowAntennaForm(false);
    setEditingAntenna(null);
    fetchAntennas();
  };

  const handleRouteFormSuccess = () => {
    setShowRouteForm(false);
    setCurrentRoutePoints([]);
    fetchCableRoutes();
  };

  const handleDeleteRoute = async (id) => {

    try {
      await api.delete(`/cable-routes/${id}`);
      fetchCableRoutes();
    } catch (error) {
      alert('Error al eliminar la ruta de cable');
    }
  };

  const handleClientClick = (client) => {
    setSelectedClient(client);
    setSelectedAntenna(null);
    if (client.latitude && client.longitude) {
      setMapCenter([parseFloat(client.latitude), parseFloat(client.longitude)]);
      setMapZoom(16);
    }
  };

  const handleAntennaClick = (antenna) => {
    setSelectedAntenna(antenna);
    setSelectedClient(null);
    if (antenna.latitude && antenna.longitude) {
      setMapCenter([parseFloat(antenna.latitude), parseFloat(antenna.longitude)]);
      setMapZoom(15);
    }
  };

  const filteredClients = useMemo(() => {
    return clients.filter(client => {
      if (filterNetwork === 'all') return true;
      return client.network_type === filterNetwork;
    });
  }, [clients, filterNetwork]);

  // Clientes con ubicación
  const clientsWithLocation = useMemo(() => {
    return filteredClients.filter(c => c.latitude && c.longitude);
  }, [filteredClients]);

  // Colores por red
  const networkColors = {
    'Red Satelital': '#e74c3c',
    'Red ONT': '#3498db',
    'default': '#95a5a6'
  };

  const getNetworkColor = (networkType) => {
    return networkColors[networkType] || networkColors.default;
  };

  if (loading) {
    return <div className="loading">Cargando mapa...</div>;
  }

  return (
    <div className="map-page">
      <div className="map-sidebar">
        <div className="sidebar-header">
          <h1>🗺️ Mapa de Clientes y Cobertura</h1>
        </div>

        <div className="map-controls">
          <h3>Controles</h3>
          <div className="control-group">
            <label>
              <input
                type="checkbox"
                checked={showClients}
                onChange={(e) => setShowClients(e.target.checked)}
              />
              Mostrar Clientes
            </label>
          </div>
          <div className="control-group">
            <label>
              <input
                type="checkbox"
                checked={showAntennas}
                onChange={(e) => setShowAntennas(e.target.checked)}
              />
              Mostrar Antenas
            </label>
          </div>
          <div className="control-group">
            <label>
              <input
                type="checkbox"
                checked={showCoverage}
                onChange={(e) => setShowCoverage(e.target.checked)}
              />
              Mostrar Cobertura
            </label>
          </div>
          <div className="control-group">
            <label>
              <input
                type="checkbox"
                checked={showCableRoutes}
                onChange={(e) => setShowCableRoutes(e.target.checked)}
              />
              Mostrar Rutas de Cable (ONT)
            </label>
          </div>
          <div className="control-group">
            <label>Filtrar por Red:</label>
            <select value={filterNetwork} onChange={(e) => setFilterNetwork(e.target.value)}>
              <option value="all">Todas las redes</option>
              {networks.map(network => (
                <option key={network.id} value={network.name}>{network.name}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="cable-routes-section">
          <div className="section-header">
            <h3>Rutas de Cable (ONT)</h3>
            <button onClick={() => setShowRouteForm(true)} className="btn-add-antenna">
              ➕ Agregar Ruta
            </button>
          </div>
          <div className="routes-list">
            {cableRoutes.length === 0 ? (
              <p className="no-data">No hay rutas de cable registradas</p>
            ) : (
              cableRoutes.map(route => (
                <div
                  key={route.id}
                  className="route-item"
                >
                  <div className="route-info">
                    <strong>{route.name}</strong>
                    <div className="route-details">
                      <span>{route.points_count} puntos</span>
                      {route.distance && <span>{route.distance.toFixed(2)} km</span>}
                    </div>
                    {route.description && <div className="route-description">{route.description}</div>}
                  </div>
                  <div className="route-actions">
                    <button onClick={(e) => { e.stopPropagation(); handleDeleteRoute(route.id); }} className="btn-delete-small">
                      🗑️
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="antenas-section">
          <div className="section-header">
            <h3>Antenas Proveedoras</h3>
            <button onClick={handleAddAntenna} className="btn-add-antenna">
              ➕ Agregar Antena
            </button>
          </div>
          <div className="antennas-list">
            {antennas.length === 0 ? (
              <p className="no-data">No hay antenas registradas</p>
            ) : (
              antennas.map(antenna => (
                <div
                  key={antenna.id}
                  className={`antenna-item ${selectedAntenna?.id === antenna.id ? 'selected' : ''}`}
                  onClick={() => handleAntennaClick(antenna)}
                >
                  <div className="antenna-info">
                    <strong>{antenna.name}</strong>
                    <div className="antenna-details">
                      <span>Red: {antenna.network_type}</span>
                      {antenna.azimuth && <span>Azimut: {antenna.azimuth}°</span>}
                      {antenna.aperture && <span>Apertura: {antenna.aperture}°</span>}
                      {antenna.range && <span>Alcance: {antenna.range} km</span>}
                    </div>
                  </div>
                  <div className="antenna-actions">
                    <button onClick={(e) => { e.stopPropagation(); handleEditAntenna(antenna); }} className="btn-edit-small">
                      ✏️
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); handleDeleteAntenna(antenna.id); }} className="btn-delete-small">
                      🗑️
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="clients-section">
          <h3>Clientes ({clientsWithLocation.length}/{filteredClients.length})</h3>
          <div className="clients-list">
            {filteredClients.length === 0 ? (
              <p className="no-data">No hay clientes para mostrar</p>
            ) : (
              filteredClients.slice(0, 50).map(client => (
                <div
                  key={client.id}
                  className={`client-item ${selectedClient?.id === client.id ? 'selected' : ''}`}
                  onClick={() => handleClientClick(client)}
                >
                  <div className="client-info">
                    <strong>{client.name}</strong>
                    <div className="client-details">
                      <span>#{client.client_number}</span>
                      {client.network_type && <span className="network-badge">{client.network_type}</span>}
                      {!client.latitude || !client.longitude ? (
                        <span className="no-location">📍❌</span>
                      ) : (
                        <span className="has-location">📍✓</span>
                      )}
                    </div>
                    <div className="client-address">{client.address}</div>
                  </div>
                </div>
              ))
            )}
            {filteredClients.length > 50 && (
              <p className="info-text">Mostrando primeros 50 clientes. Usa los filtros para ver más.</p>
            )}
          </div>
        </div>
      </div>

      <div className="map-container-wrapper">
        <MapContainer
          center={mapCenter}
          zoom={mapZoom}
          style={{ height: '100%', width: '100%' }}
          className="leaflet-map"
        >
          <ChangeView center={mapCenter} zoom={mapZoom} />
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          {/* Marcadores de antenas */}
          {showAntennas && antennas.map(antenna => {
            if (!antenna.latitude || !antenna.longitude) return null;
            
            const position = [parseFloat(antenna.latitude), parseFloat(antenna.longitude)];
            
            return (
              <React.Fragment key={`antenna-${antenna.id}`}>
                <Marker
                  position={position}
                  icon={antennaIcon}
                  eventHandlers={{
                    click: () => handleAntennaClick(antenna)
                  }}
                >
                  <Popup>
                    <div className="popup-content">
                      <h4>📡 {antenna.name}</h4>
                      <p><strong>Red:</strong> {antenna.network_type}</p>
                      <p><strong>Dirección:</strong> {antenna.address}</p>
                      <p><strong>Azimut:</strong> {antenna.azimuth}°</p>
                      <p><strong>Apertura:</strong> {antenna.aperture}°</p>
                      <p><strong>Alcance:</strong> {antenna.range} km</p>
                      {antenna.notes && <p><strong>Notas:</strong> {antenna.notes}</p>}
                    </div>
                  </Popup>
                </Marker>
                
                {/* Área de cobertura */}
                {showCoverage && (
                  <CoverageWedge antenna={antenna} color={getNetworkColor(antenna.network_type)} />
                )}
              </React.Fragment>
            );
          })}

          {/* Marcadores de clientes */}
          {showClients && clientsWithLocation.map(client => {
            const position = [parseFloat(client.latitude), parseFloat(client.longitude)];
            
            return (
              <Marker
                key={`client-${client.id}`}
                position={position}
                icon={clientIcon}
                eventHandlers={{
                  click: () => handleClientClick(client)
                }}
              >
                <Popup>
                  <div className="popup-content">
                    <h4>👤 {client.name}</h4>
                    <p><strong>Número:</strong> #{client.client_number}</p>
                    <p><strong>Red:</strong> {client.network_type || 'Sin red'}</p>
                    <p><strong>Dirección:</strong> {client.address}</p>
                    {client.phone && <p><strong>Teléfono:</strong> {client.phone}</p>}
                    {client.package_name && <p><strong>Paquete:</strong> {client.package_name}</p>}
                  </div>
                </Popup>
              </Marker>
            );
          })}

          {/* Rutas de cable (ONT) */}
          {showCableRoutes && cableRoutes.map(route => {
            if (!route.points || route.points.length < 2) return null;
            
            const positions = route.points.map(p => [p.lat, p.lng]);
            const color = route.color || '#3498db';
            
            return (
              <Polyline
                key={`route-${route.id}`}
                positions={positions}
                color={color}
                weight={4}
                opacity={0.7}
              >
                <Popup>
                  <div className="popup-content">
                    <h4>🔌 {route.name}</h4>
                    <p><strong>Red:</strong> {route.network_type}</p>
                    {route.description && <p><strong>Descripción:</strong> {route.description}</p>}
                    <p><strong>Puntos:</strong> {route.points.length}</p>
                    <p><strong>Distancia:</strong> {route.distance?.toFixed(2)} km</p>
                  </div>
                </Popup>
              </Polyline>
            );
          })}
        </MapContainer>

        <div className="map-legend">
          <h4>Leyenda</h4>
          <div className="legend-item">
            <span className="legend-icon">📡</span>
            <span>Antenas Proveedoras</span>
          </div>
          <div className="legend-item">
            <span className="legend-icon">👤</span>
            <span>Clientes</span>
          </div>
          {showCoverage && (
            <div className="legend-item">
              <span className="legend-icon">◔</span>
              <span>Área de Cobertura</span>
            </div>
          )}
          {showCableRoutes && cableRoutes.length > 0 && (
            <div className="legend-item">
              <span className="legend-icon">🔌</span>
              <span>Rutas de Cable (ONT)</span>
            </div>
          )}
        </div>

        <div className="map-info-box">
          <p><strong>Clientes en mapa:</strong> {clientsWithLocation.length} de {filteredClients.length}</p>
          <p><strong>Antenas registradas:</strong> {antennas.length}</p>
          <p><strong>Rutas de cable:</strong> {cableRoutes.length}</p>
          <p className="help-text">💡 Haz clic en los marcadores para ver detalles</p>
        </div>
      </div>

      {showAntennaForm && (
        <AntennaForm
          antenna={editingAntenna}
          networks={networks}
          onClose={() => {
            setShowAntennaForm(false);
            setEditingAntenna(null);
          }}
          onSuccess={handleFormSuccess}
        />
      )}

      {showRouteForm && (
        <CableRouteForm
          networks={networks}
          onClose={() => {
            setShowRouteForm(false);
            setCurrentRoutePoints([]);
          }}
          onSuccess={handleRouteFormSuccess}
        />
      )}
    </div>
  );
};

// Componente de formulario de antena
const AntennaForm = ({ antenna, networks, onClose, onSuccess }) => {
  const getLocalDateString = (date = new Date()) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const [formData, setFormData] = useState({
    name: '',
    network_type: '',
    address: '',
    latitude: '',
    longitude: '',
    azimuth: '0',
    aperture: '60',
    range: '2',
    notes: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (antenna) {
      setFormData({
        name: antenna.name || '',
        network_type: antenna.network_type || '',
        address: antenna.address || '',
        latitude: antenna.latitude || '',
        longitude: antenna.longitude || '',
        azimuth: antenna.azimuth || '0',
        aperture: antenna.aperture || '60',
        range: antenna.range || '2',
        notes: antenna.notes || ''
      });
    }
  }, [antenna]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (antenna) {
        await api.put(`/antennas/${antenna.id}`, formData);
      } else {
        await api.post('/antennas', formData);
      }
      onSuccess();
    } catch (error) {
      setError(error.response?.data?.error || 'Error al guardar la antena');
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{antenna ? 'Editar Antena' : 'Registrar Antena'}</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>
        <form onSubmit={handleSubmit}>
          {error && <div className="error-message">{error}</div>}
          <div className="form-group">
            <label>Nombre de la Antena *</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              placeholder="Ej: Antena Principal, Torre Norte, etc."
            />
          </div>
          <div className="form-group">
            <label>Red *</label>
            <select
              name="network_type"
              value={formData.network_type}
              onChange={handleChange}
              required
            >
              <option value="">Seleccionar red</option>
              {networks.map((network) => (
                <option key={network.id} value={network.name}>
                  {network.name}
                </option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Dirección *</label>
            <input
              type="text"
              name="address"
              value={formData.address}
              onChange={handleChange}
              required
              placeholder="Dirección de la antena"
            />
            <small>Puedes buscar en Google Maps y copiar las coordenadas</small>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Latitud *</label>
              <input
                type="number"
                name="latitude"
                value={formData.latitude}
                onChange={handleChange}
                step="0.000001"
                required
                placeholder="19.432608"
              />
            </div>
            <div className="form-group">
              <label>Longitud *</label>
              <input
                type="number"
                name="longitude"
                value={formData.longitude}
                onChange={handleChange}
                step="0.000001"
                required
                placeholder="-99.133209"
              />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Azimut (Dirección) *</label>
              <input
                type="number"
                name="azimuth"
                value={formData.azimuth}
                onChange={handleChange}
                min="0"
                max="360"
                step="1"
                required
                placeholder="0-360°"
              />
              <small>0° = Norte, 90° = Este, 180° = Sur, 270° = Oeste</small>
            </div>
            <div className="form-group">
              <label>Apertura (Ángulo) *</label>
              <input
                type="number"
                name="aperture"
                value={formData.aperture}
                onChange={handleChange}
                min="1"
                max="360"
                step="1"
                required
                placeholder="30-120°"
              />
              <small>Ángulo de cobertura de la antena</small>
            </div>
          </div>
          <div className="form-group">
            <label>Alcance (km) *</label>
            <input
              type="number"
              name="range"
              value={formData.range}
              onChange={handleChange}
              min="0.1"
              step="0.1"
              required
              placeholder="2.5"
            />
            <small>Radio de cobertura en kilómetros</small>
          </div>
          <div className="form-group">
            <label>Notas</label>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              rows="3"
              placeholder="Notas adicionales (opcional)"
            />
          </div>
          <div className="form-actions">
            <button type="button" className="btn-cancel" onClick={onClose}>
              Cancelar
            </button>
            <button type="submit" className="btn-submit" disabled={loading}>
              {loading ? 'Guardando...' : 'Guardar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Componente de formulario para rutas de cable
const CableRouteForm = ({ networks, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    name: '',
    network_type: 'Red ONT',
    description: '',
    color: '#3498db',
    points_input: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Parsear puntos desde el input
      const lines = formData.points_input.trim().split('\n');
      const points = [];
      
      for (const line of lines) {
        const trimmedLine = line.trim();
        if (!trimmedLine) continue;
        
        // Formato esperado: lat, lng (ejemplo: 19.432608, -99.133209)
        const parts = trimmedLine.split(',').map(p => p.trim());
        if (parts.length === 2) {
          const lat = parseFloat(parts[0]);
          const lng = parseFloat(parts[1]);
          
          if (!isNaN(lat) && !isNaN(lng)) {
            points.push({ lat, lng });
          }
        }
      }
      
      if (points.length < 2) {
        setError('Debes ingresar al menos 2 puntos válidos (formato: lat, lng)');
        setLoading(false);
        return;
      }

      const dataToSend = {
        name: formData.name,
        description: formData.description,
        network_type: formData.network_type,
        color: formData.color,
        points: points
      };

      await api.post('/cable-routes', dataToSend);
      onSuccess();
    } catch (error) {
      setError(error.response?.data?.error || 'Error al guardar la ruta de cable');
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Dibujar Ruta de Cable</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>
        <form onSubmit={handleSubmit}>
          {error && <div className="error-message">{error}</div>}
          <div className="form-group">
            <label>Nombre de la Ruta *</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              placeholder="Ej: Cable Principal, Ruta Norte, etc."
            />
          </div>
          <div className="form-group">
            <label>Red *</label>
            <select
              name="network_type"
              value={formData.network_type}
              onChange={handleChange}
              required
            >
              {networks.map((network) => (
                <option key={network.id} value={network.name}>
                  {network.name}
                </option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Descripción</label>
            <input
              type="text"
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Descripción de la ruta (opcional)"
            />
          </div>
          <div className="form-group">
            <label>Color</label>
            <input
              type="color"
              name="color"
              value={formData.color}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Puntos de la Ruta *</label>
            <textarea
              name="points_input"
              value={formData.points_input}
              onChange={handleChange}
              rows="10"
              required
              placeholder={'Ingresa las coordenadas de la ruta, una por línea.\nFormato: latitud, longitud\n\nEjemplo:\n19.432608, -99.133209\n19.433012, -99.132845\n19.433456, -99.132501'}
              style={{ fontFamily: 'monospace', fontSize: '0.9rem' }}
            />
            <small style={{ display: 'block', marginTop: '5px' }}>
              💡 Cada línea debe tener: latitud, longitud<br/>
              📍 Puedes copiar coordenadas desde Google Maps haciendo clic derecho en el mapa
            </small>
          </div>
          <div className="form-actions">
            <button type="button" className="btn-cancel" onClick={onClose}>
              Cancelar
            </button>
            <button type="submit" className="btn-submit" disabled={loading}>
              {loading ? 'Guardando...' : 'Guardar Ruta'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Map;
