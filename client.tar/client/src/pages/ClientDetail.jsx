import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';
import { generateClientPDF } from '../utils/pdfGenerator';
import './ClientDetail.css';

const ClientDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [client, setClient] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [portalEnabled, setPortalEnabled] = useState(false);
  const [portalPassword, setPortalPassword] = useState('');
  const [portalSaving, setPortalSaving] = useState(false);
  const [portalFlash, setPortalFlash] = useState(null);
  const [pdfGenerating, setPdfGenerating] = useState(false);

  useEffect(() => {
    setLoadError(null);
    fetchClient();
  }, [id]);

  const fetchClient = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const response = await api.get(`/clients/${id}`);
      setClient(response.data);
      setPortalEnabled(response.data.portal_enabled === 1 || response.data.portal_enabled === true);
    } catch (error) {
      console.error('Error al cargar cliente:', error);
      setLoadError(error.response?.data?.error || 'Error al cargar el cliente');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPDF = () => {
    if (!client || pdfGenerating) return;
    setPdfGenerating(true);
    setTimeout(() => {
      try {
        generateClientPDF(client);
      } finally {
        setPdfGenerating(false);
      }
    }, 0);
  };

  if (loading && !client) {
    return <div className="loading">Cargando cliente...</div>;
  }

  if (loadError && !client) {
    return (
      <div className="client-detail">
        <div className="detail-header">
          <button className="btn-back" onClick={() => navigate('/clients')}>← Volver</button>
        </div>
        <div className="error-message-banner">{loadError}</div>
        <p style={{ marginTop: '1rem' }}>
          <button className="btn-primary" onClick={fetchClient}>Reintentar</button>
        </p>
      </div>
    );
  }

  if (!client) {
    return (
      <div className="client-detail">
        <div className="detail-header">
          <button className="btn-back" onClick={() => navigate('/clients')}>← Volver</button>
        </div>
        <div className="error">Cliente no encontrado</div>
      </div>
    );
  }

  return (
    <div className="client-detail">
      <div className="detail-header">
        <button className="btn-back" onClick={() => navigate('/clients')}>
          ← Volver
        </button>
        <h1>{client.name}</h1>
        <button className="btn-download" onClick={handleDownloadPDF} disabled={pdfGenerating}>
          {pdfGenerating ? '⏳ Generando...' : '📥 Descargar PDF'}
        </button>
      </div>

      <div className="detail-content">
        <div className="detail-section">
          <h2>Información Personal</h2>
          <div className="info-grid">
            {client.client_number && (
              <div className="info-item">
                <strong>🔢 Número de Cliente:</strong>
                <p>{client.client_number}</p>
              </div>
            )}
            <div className="info-item">
              <strong>📍 Domicilio:</strong>
              <p>{client.address}</p>
            </div>
            {client.phone && (
              <div className="info-item">
                <strong>📞 Teléfono:</strong>
                <p>
                  {client.phone}
                  <a
                    href={`https://wa.me/${client.phone.replace(/\D/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="whatsapp-link"
                    title="Abrir WhatsApp"
                  >
                    💬 WhatsApp
                  </a>
                </p>
              </div>
            )}
            {client.email && (
              <div className="info-item">
                <strong>📧 Email:</strong>
                <p>{client.email}</p>
              </div>
            )}
            {client.network_type && (
              <div className="info-item">
                <strong>📡 Tipo de Red:</strong>
                <p>{client.network_type}</p>
              </div>
            )}
            {client.package_name && (
              <div className="info-item">
                <strong>📦 Paquete Contratado:</strong>
                <p>{client.package_name} - {client.speed} - ${client.package_price}</p>
              </div>
            )}
            {client.notes && (
              <div className="info-item full-width">
                <strong>📝 Anotaciones:</strong>
                <p>{client.notes}</p>
              </div>
            )}
          </div>
        </div>

        <div className="detail-section">
          <h2>🌐 Portal del Cliente</h2>
          {portalFlash && (
            <div className={`flash-banner ${portalFlash.type}`}>
              {portalFlash.message}
              <button type="button" className="flash-dismiss" onClick={() => setPortalFlash(null)} aria-label="Cerrar">×</button>
            </div>
          )}
          <p className="section-desc">Permite al cliente consultar saldo, pagos, recibos y abrir tickets en <a href="/portal/login" target="_blank" rel="noopener noreferrer">/portal</a></p>
          <div className="portal-setup">
            <label className="portal-check">
              <input
                type="checkbox"
                checked={portalEnabled}
                onChange={(e) => setPortalEnabled(e.target.checked)}
              />
              Habilitar acceso al portal
            </label>
            <div className="portal-password-row">
              <input
                type="password"
                placeholder="Nueva contraseña (mín. 6 caracteres)"
                value={portalPassword}
                onChange={(e) => setPortalPassword(e.target.value)}
              />
              <button
                className="btn-save-portal"
                onClick={async () => {
                  setPortalSaving(true);
                  try {
                    await api.post(`/clients/${id}/portal-setup`, {
                      portal_enabled: portalEnabled,
                      portal_password: portalPassword || undefined
                    });
                    setPortalPassword('');
                    setPortalFlash({ type: 'success', message: 'Portal configurado correctamente' });
                  } catch (err) {
                    setPortalFlash({ type: 'error', message: err.response?.data?.error || 'Error al guardar' });
                  } finally {
                    setPortalSaving(false);
                  }
                }}
                disabled={portalSaving}
              >
                {portalSaving ? 'Guardando...' : 'Guardar'}
              </button>
            </div>
            {client.client_number && (
              <>
                <p className="portal-hint">El cliente accede con: número <strong>{client.client_number}</strong> y la contraseña que configures.</p>
                <button
                  type="button"
                  className="btn-secondary"
                  style={{ marginTop: 8 }}
                  onClick={async () => {
                    try {
                      const res = await api.post(`/clients/${id}/generate-portal-reset-code`);
                      setPortalFlash({ type: 'success', message: `Código: ${res.data.code}. Válido 1 hora. Indica al cliente que use "Olvidé mi contraseña" en el portal e ingrese su número y este código.` });
                    } catch (err) {
                      setPortalFlash({ type: 'error', message: err.response?.data?.error || 'Error al generar código' });
                    }
                  }}
                >
                  Generar código de restablecimiento
                </button>
              </>
            )}
            {(client.app_version_name || client.app_version_code) && (
              <p className="portal-hint" style={{ marginTop: 8 }}>
                📱 <strong>Versión de la app:</strong> {client.app_version_name || '?'} (código: {client.app_version_code ?? '?'})
                {client.app_last_seen && (
                  <span> · Última vez: {new Date(client.app_last_seen).toLocaleString('es-MX', { dateStyle: 'short', timeStyle: 'short' })}</span>
                )}
              </p>
            )}
          </div>
        </div>

        <div className="detail-section">
          <h2>Historial de Pagos</h2>
          {client.payments && client.payments.length > 0 ? (
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Fecha</th>
                    <th>Monto</th>
                    <th>Recibo</th>
                    <th>Notas</th>
                  </tr>
                </thead>
                <tbody>
                  {client.payments.map((payment) => (
                    <tr key={payment.id}>
                      <td>{new Date(payment.payment_date).toLocaleDateString('es-ES')}</td>
                      <td>${payment.amount}</td>
                      <td>{payment.receipt_number || '-'}</td>
                      <td>{payment.notes || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="empty-message">No hay pagos registrados</p>
          )}
        </div>

        <div className="detail-section">
          <h2>Instalaciones</h2>
          {client.installations && client.installations.length > 0 ? (
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Fecha</th>
                    <th>Tipo</th>
                    <th>Paquete</th>
                    <th>Estado</th>
                    <th>Notas</th>
                  </tr>
                </thead>
                <tbody>
                  {client.installations.map((installation) => (
                    <tr key={installation.id}>
                      <td>{new Date(installation.installation_date).toLocaleDateString('es-ES')}</td>
                      <td>{installation.installation_type}</td>
                      <td>
                        {installation.package_name ? (
                          <span style={{ fontSize: '0.9em' }}>
                            {installation.package_name}
                            {installation.package_speed && ` - ${installation.package_speed}`}
                            {installation.package_price && ` - $${installation.package_price}`}
                          </span>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td>
                        <span className={`status-badge status-${installation.status}`}>
                          {installation.status}
                        </span>
                      </td>
                      <td>{installation.notes || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="empty-message">No hay instalaciones registradas</p>
          )}
        </div>

        <div className="detail-section">
          <h2>Folios de Reparación</h2>
          {client.folios && client.folios.length > 0 ? (
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Folio</th>
                    <th>Fecha de Visita</th>
                    <th>Problema</th>
                    <th>Estado</th>
                    <th>Notas Técnico</th>
                  </tr>
                </thead>
                <tbody>
                  {client.folios.map((folio) => {
                    // Función helper para formatear fechas sin problemas de zona horaria
                    const formatDate = (dateString) => {
                      if (!dateString) return '-';
                      const dateParts = dateString.split('T')[0].split('-');
                      if (dateParts.length === 3) {
                        const [year, month, day] = dateParts;
                        const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
                        return date.toLocaleDateString('es-ES');
                      }
                      return new Date(dateString).toLocaleDateString('es-ES');
                    };
                    return (
                    <tr key={folio.id}>
                      <td><strong>{folio.folio_number}</strong></td>
                      <td>{formatDate(folio.visit_date)}</td>
                      <td>{folio.problem_description || '-'}</td>
                      <td>
                        <span className={`status-badge status-${folio.status}`}>
                          {folio.status}
                        </span>
                      </td>
                      <td>{folio.technician_notes || '-'}</td>
                    </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="empty-message">No hay folios registrados</p>
          )}
        </div>

      </div>
    </div>
  );
};

export default ClientDetail;

