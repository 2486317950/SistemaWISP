import React, { useState, useEffect } from 'react';
import api from '../services/api';
import PackageForm from '../components/PackageForm';
import './Packages.css';

const Packages = () => {
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingPackage, setEditingPackage] = useState(null);
  const [filter, setFilter] = useState('all'); // 'all', 'active', 'inactive'

  useEffect(() => {
    fetchPackages();
  }, []);

  const fetchPackages = async () => {
    try {
      const response = await api.get('/packages');
      setPackages(response.data);
    } catch (error) {
      console.error('Error al cargar paquetes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {

    try {
      await api.delete(`/packages/${id}`);
      fetchPackages();
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Error al eliminar el paquete';
      alert(errorMessage);
    }
  };

  const handleFormSubmit = () => {
    setShowForm(false);
    setEditingPackage(null);
    fetchPackages();
  };

  const filteredPackages = packages.filter(pkg => {
    if (filter === 'active') return pkg.is_active === 1 || pkg.is_active === true;
    if (filter === 'inactive') return pkg.is_active === 0 || pkg.is_active === false;
    return true; // 'all'
  });

  if (loading) {
    return <div className="loading">Cargando paquetes...</div>;
  }

  return (
    <div className="packages-page">
      <div className="page-header">
        <h1>Paquetes de Internet</h1>
        <button className="btn-primary" onClick={() => setShowForm(true)}>
          + Agregar Paquete
        </button>
      </div>

      <div className="package-filters">
        <button
          className={`package-filter-btn ${filter === 'all' ? 'active' : ''}`}
          onClick={() => setFilter('all')}
        >
          📦 Todos
        </button>
        <button
          className={`package-filter-btn ${filter === 'active' ? 'active' : ''}`}
          onClick={() => setFilter('active')}
        >
          ✅ Activos
        </button>
        <button
          className={`package-filter-btn ${filter === 'inactive' ? 'active' : ''}`}
          onClick={() => setFilter('inactive')}
        >
          ❌ Inactivos
        </button>
      </div>

      {showForm && (
        <PackageForm
          packageData={editingPackage}
          onClose={() => {
            setShowForm(false);
            setEditingPackage(null);
          }}
          onSuccess={handleFormSubmit}
        />
      )}

      <div className="packages-grid">
        {filteredPackages.map((pkg) => (
          <div key={pkg.id} className={`package-card ${(pkg.is_active === 0 || pkg.is_active === false) ? 'inactive' : ''}`}>
            <div className="package-header">
              <h3>
                {pkg.name}
                {(pkg.is_active === 0 || pkg.is_active === false) && (
                  <span className="status-badge inactive-badge">Inactivo</span>
                )}
                {(pkg.is_active === 1 || pkg.is_active === true) && (
                  <span className="status-badge active-badge">Activo</span>
                )}
              </h3>
              <div className="package-actions">
                <button
                  className="btn-icon"
                  onClick={() => {
                    setEditingPackage(pkg);
                    setShowForm(true);
                  }}
                  title="Editar"
                >
                  ✏️
                </button>
                <button
                  className="btn-icon"
                  onClick={() => handleDelete(pkg.id)}
                  title="Eliminar"
                >
                  🗑️
                </button>
              </div>
            </div>
            <div className="package-info">
              {pkg.network_name && (
                <div className="package-network">
                  <span className="network-label">Red:</span>
                  <span className="network-value">{pkg.network_name}</span>
                </div>
              )}
              <div className="package-speed">
                <span className="speed-label">Velocidad:</span>
                <span className="speed-value">{pkg.speed}</span>
              </div>
              <div className="package-price">
                <span className="price-label">Precio:</span>
                <span className="price-value">${pkg.price}</span>
              </div>
              {pkg.description && (
                <div className="package-description">
                  <p>{pkg.description}</p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {filteredPackages.length === 0 && (
        <div className="empty-state">
          <p>
            {filter === 'all' && 'No hay paquetes registrados'}
            {filter === 'active' && 'No hay paquetes activos'}
            {filter === 'inactive' && 'No hay paquetes inactivos'}
          </p>
        </div>
      )}
    </div>
  );
};

export default Packages;



