import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    host: '0.0.0.0', // Permitir acceso desde la red local
    allowedHosts: [
      'sistemacdcom.ngrok.dev',
      '.ngrok.dev',
      '.ngrok-free.app',
      'localhost'
    ],
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
        secure: false
      }
    }
  }
})

